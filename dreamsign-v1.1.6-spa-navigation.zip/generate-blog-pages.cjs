const fs = require('fs');
const path = require('path');
const fm = require('front-matter');
const SITE_URL = 'https://dreamsign.cl';
const blogDir = path.join(__dirname, 'public', 'blog');
const distBlogDir = path.join(__dirname, 'dist', 'blog');
const template = fs.readFileSync(path.join(__dirname, 'dist', 'index.html'), 'utf8');
const esc = (v='') => String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
const abs = (v, fallback) => { const u=v||fallback; return /^https?:\/\//i.test(u)?u:`${SITE_URL}/${String(u).replace(/^\//,'')}`; };
for (const file of fs.readdirSync(blogDir).filter(f=>f.endsWith('.md'))) {
  const slug=file.slice(0,-3); const {attributes}=fm(fs.readFileSync(path.join(blogDir,file),'utf8')); if(attributes.published===false) continue;
  const canonical=attributes.canonicalUrl||`${SITE_URL}/blog/${slug}`; const image=abs(attributes.ogImage||attributes.image,`${SITE_URL}/blog/assets/default.jpg`); const title=`${attributes.title||'Artículo'} | Dreamsign`; const desc=attributes.description||'Artículos sobre tecnología, software y soluciones digitales de Dreamsign.';
  const schema={"@context":"https://schema.org","@type":"BlogPosting",headline:attributes.title,description:desc,datePublished:attributes.date,dateModified:attributes.dateModified||attributes.date,author:{"@type":"Person",name:attributes.author||'Dreamsign'},publisher:{"@type":"Organization",name:'Dreamsign',url:SITE_URL,logo:{"@type":"ImageObject",url:`${SITE_URL}/assets/logo.png`}},image:[image],mainEntityOfPage:{"@type":"WebPage","@id":canonical},inLanguage:attributes.language||'es'};
  const head=`<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${esc(canonical)}"><meta property="og:type" content="article"><meta property="og:title" content="${esc(attributes.title||'Artículo')}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${esc(canonical)}"><meta property="og:image" content="${esc(image)}"><meta property="og:image:alt" content="${esc(attributes.title||'Artículo Dreamsign')}"><meta property="og:site_name" content="Dreamsign"><meta property="og:locale" content="es_CL"><meta property="article:published_time" content="${esc(attributes.date||'')}"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${esc(attributes.title||'Artículo')}"><meta name="twitter:description" content="${esc(desc)}"><meta name="twitter:image" content="${esc(image)}"><meta name="twitter:image:alt" content="${esc(attributes.title||'Artículo Dreamsign')}"><script type="application/ld+json">${JSON.stringify(schema)}</script>`;
  const html=template.replace('</head>',`${head}</head>`); const out=path.join(distBlogDir,slug); fs.mkdirSync(out,{recursive:true}); fs.writeFileSync(path.join(out,'index.html'),html);
}
console.log('Blog static HTML generated.');
