# Analytics — Dreamsign

Esta versión prepara la aplicación para enviar eventos a Google Tag Manager mediante `window.dataLayer`.

## Arquitectura

```text
React
  ↓
dataLayer
  ↓
Google Tag Manager (GTM-MLK7VRHN)
  ↓
GA4 / otras plataformas
```

En esta etapa **no se envían eventos directamente a GA4 desde React**. La aplicación solo publica eventos en `dataLayer`.

## Eventos implementados

| Evento | Cuándo ocurre | Datos principales |
|---|---|---|
| `page_view` | Al entrar o navegar a una ruta SPA | `page_path`, `page_location`, `page_title` |
| `cta_click` | Al pulsar un CTA relevante | `cta_name`, `destination`, `cta_location` |
| `whatsapp_click` | Al pulsar WhatsApp de contacto | `click_location`, `destination_type` |
| `phone_click` | Al pulsar un teléfono de contacto | `click_location` |
| `email_click` | Al pulsar el correo de ventas | `click_location` |
| `contact_form_start` | Primera interacción con el formulario | `form_name` |
| `contact_form_submit` | Formulario enviado correctamente | `form_name` |
| `contact_form_error` | Error de CAPTCHA, servidor o red | `form_name`, `error_type` |
| `blog_view` | Al cargar un artículo | `content_type`, `content_slug`, `content_title`, `content_categories` |
| `blog_share` | Al compartir/copiar un artículo | `platform`, `content_type`, `content_title` |
| `service_view` | Al entrar a una página de servicio | `service_name`, `page_path` |
| `product_view` | Al entrar a dsRest | `product_name`, `page_path` |

## Prueba local

Después de ejecutar:

```bash
npm install
npm run dev
```

abre la consola del navegador y ejecuta:

```js
window.dataLayer
```

Deberías ver objetos con propiedades como:

```js
{
  event: "page_view",
  page_path: "/",
  page_location: "http://localhost:5173/",
  page_title: "..."
}
```

Para limpiar el historial durante una prueba:

```js
window.dataLayer.length = 0
```

Luego recarga o realiza una acción y vuelve a ejecutar:

```js
window.dataLayer
```

## Importante

Los eventos del formulario **no incluyen nombre, correo, asunto, comentario ni ningún otro dato introducido por el usuario**. Solo se registra el estado de la interacción.

La configuración de tags, triggers y conversiones de GA4 se realizará posteriormente en GTM.


## v1.1.5 — Captura robusta de page_title

- `page_view` espera de forma robusta a que `document.title` esté disponible después del render de `react-helmet-async`.
- Mantiene la deduplicación compatible con React StrictMode.
- Si el título no aparece dentro del límite de espera, registra el `page_view` igualmente sin inventar un título.

## v1.1.4 — Normalización de page_view

- `page_path` se normaliza a `pathname`, sin query parameters.
- `page_location` conserva la URL completa del navegador.
- El `page_view` espera hasta que `react-helmet-async` haya actualizado `document.title` (con un límite de espera), evitando registrar un título vacío cuando la página ya define uno.
- La deduplicación sigue considerando `pathname + search`, evitando duplicados de React StrictMode sin perder cambios reales de URL.
- `trackPageView()` también normaliza `page_path` como defensa a nivel de la capa de analytics.
