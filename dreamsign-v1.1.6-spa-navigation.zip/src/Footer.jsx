
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMobileScreenButton, faEnvelope, faLocationDot } from '@fortawesome/free-solid-svg-icons';
import SocialNetworks from './assets/components/SocialNetworks';
import ContactForm from './assets/components/ContactForm';
import { pushAnalyticsEvent } from './utils/analytics';


function Footer(){
    return(
        <>
            <footer className="footer-prime">
                <div id="contact" className="footer-content">
                    <div className="container">
                        <div className="row">
                            <div className="col-12 col-md-6 order-2 order-md-1">
                                <div className="how-contact">
                                    <h3>Elige cómo contactarnos</h3>
                                    <SocialNetworks />
                                </div>

                                <hr/>

                                <ul className="other-contact">
                                    <li>
                                        <h4>Dirección:</h4>
                                        <a 
                                            href="https://maps.app.goo.gl/Bw9UFmAf6VDUpvah8" 
                                            target="_blank" 
                                            aria-label="Ver dirección en Google Maps"
                                            rel="noopener noreferrer">
                                            <FontAwesomeIcon icon={faLocationDot} aria-hidden="true" />
                                            <span>Badajoz 100, Oficina 1014, Las Condes, Región Metropolitana</span>
                                        </a>
                                    </li>
                                    <li>
                                        <h4>Ventas:</h4>
                                        <p>
                                            <a href="tel:+56937351500" target="_blank" aria-label="Llamar a ventas al (+569) 3735 1500" onClick={() => pushAnalyticsEvent("phone_click", { click_location: "footer" })}>
                                                <FontAwesomeIcon icon={faMobileScreenButton} aria-hidden="true" />
                                                <span>(+569) 3735 1500</span>
                                            </a>
                                        </p>
                                        <p>
                                            <a href="mailto:ventas@dreamsign.cl" target="_blank" onClick={() => pushAnalyticsEvent("email_click", { click_location: "footer" })}>
                                                <FontAwesomeIcon icon={faEnvelope} aria-hidden="true" />
                                                <span>ventas@dreamsign.cl</span>
                                            </a>
                                        </p>
                                    </li>
                                </ul>
                            </div>
                            <div className="col-12 col-md-6 order-1 order-md-2">
                                <h4>¡Cuéntanos de tu proyecto!</h4>
                                <ContactForm/>
                            </div>
                        </div>
                    </div>
                    <div className="signature">
                        <p><small>Dreamsign &copy; <time dateTime="2020">2020</time> - Todos los derechos reservados</small></p>
                    </div>
                </div>
            </footer>
            <div className="how-contact-bar">
                <span className="d-block fs-5 mb-1">Elige cómo contactarnos</span>
                <SocialNetworks />
                <div className="signature">
                    <p><small>Dreamsign &copy; <time dateTime="2020">2020</time> - Todos los derechos reservados</small></p>
                </div>
            </div>
        </>
    );
}

export default Footer