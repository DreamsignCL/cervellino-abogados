import React, { useState, useEffect } from "react"
import logo from './assets/img/logo-dreamsign.svg';
import MainNav from './assets/components/MainNav'
import { Link } from 'react-router-dom';

function Header(){
    const [scroll, setScroll] = useState(false);
    
    useEffect(() => {
        const handleScroll = () => setScroll(window.scrollY > 10);
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    return(
        <header className={scroll ? "header-prime scrolled" : "header-prime"}>
            <div className="container">
                <div className="d-flex justify-content-between align-items-center">
                    <Link to="/" aria-label="Ir a la página de inicio">
                        <img src={logo} width="100%" height="100%" alt="Logotipo de Dreamsign"></img>
                    </Link>

                    <MainNav />
                </div>
            </div>
        </header>
    );
}

export default Header