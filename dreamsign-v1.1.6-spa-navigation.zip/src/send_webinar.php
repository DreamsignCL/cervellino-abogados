<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

// Habilitar visualización de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: https://www.dreamsign.cl");
header("Vary: Origin");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "dream93_desarrollo", "DSAgencia2020", "dream93_web");

// Check connection
if ($conn->connect_errno) {
    echo json_encode(['status' => 'error', 'message' => 'Error en la conexión a la base de datos']);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['Nombre'] ?? '';
    $email = $_POST['Email'] ?? '';
    $web = $_POST['WebEmpresa'] ?? '';
    $googleCalendarUrl = $_POST['CalendarLink'] ?? '';

    if (empty($nombre) || empty($email)) {
        echo json_encode(["status" => "error", "message" => "Nombre y Email son requeridos"]);
        exit;
    }

    // Validar email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "El email no es válido"]);
        exit;
    }

    // Verificar si el email ya está registrado
    $stmt = $conn->prepare("SELECT email FROM webinars WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Ya estás inscrito en este webinar!"]);
        exit;
    }

    // Insertar en la base de datos
    $stmt2 = $conn->prepare("INSERT INTO webinars (nombre, email, web, webinar, fecha) VALUES (?, ?, ?, 'El ABC del Marketing Digital', NOW())");
    $stmt2->bind_param("sss", $nombre, $email, $web);
    if ($stmt2->execute()) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'mail.dreamsign.cl';
            $mail->SMTPAuth = true;
            $mail->Username = 'no-responder@dreamsign.cl';
            $mail->Password = 'DSAgencia2020';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->CharSet = 'UTF-8';

            $mail->setFrom('webinars@dreamsign.cl', 'Dreamsign');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = "Confirmación de inscripción al webinar";
            
            $mail->Body = '
                <!DOCTYPE html>
                    <html lang="es">
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>Correo Estilizado</title>
                    </head>
                    <body style="font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f7f7f7;">
                        <table style="width: 100%; background-color: #f7f7f7; padding: 20px;">
                            <tr>
                                <td align="center">
                                    <table style="max-width: 600px; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                                        <tr>
                                            <td style="
                                                background-image: url(https://dreamsign.cl/assets/bg-webinar-C4xNfJIq.avif);
                                                background-size: cover; 
                                                background-position: center center;
                                                background-color: #932791;
                                                padding: 20px; 
                                                color: #ffffff; 
                                                text-align: center;">
                                                <a href="https://dreamsign.cl?utm_source=email&utm_medium=newsletter&utm_campaign=webinar_abril2025&utm_content=logo_email" target="_blank">
                                                    <img src="https://dreamsign.cl/assets/email/logo-dreamsign.png" width="150" alt="Logo Dreamsign" style="max-width: 100%; height: auto;" />
                                                </a>
                                                <h1 style="margin: 0; font-weight: normal;">El ABC del Marketing Digital</h1>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 20px;">
                                                <p style="font-size: 16px; color: #333333; line-height: 1.5;">Hola, <strong>'.$nombre.'</strong>.</p>
                                                <p style="font-size: 16px; color: #333333; line-height: 1.5;">
                                                    Gracias por registrarte en nuestro webinar <strong>"El ABC del Marketing Digital"</strong> que realizaremos el día <strong>12 de Abril a las 11:00am</strong>. Estamos emocionados de tenerte con nosotros. A continuación, te damos algunos detalles importantes:
                                                </p>
                                                <ul style="font-size: 16px; color: #333333; line-height: 1.5;">
                                                    <li>Agenda este evento con Google Calendar en el botón "Agenda Aquí".</li>
                                                    <li>No olvides conectarte el día Sábado 12 a las 11am con el botón "Conéctate Aquí".</li>
                                                    <li>Recuerda tener encendido el audio el día de la reunión para que puedas oir todo el evento.</li>
                                                </ul>
                                                <p style="font-size: 16px; color: #333333; line-height: 1.5;">
                                                    ¡Esperamos que disfrutes de nuestro webinar!
                                                </p>
                                                <p style="font-size: 16px; color: #333333; line-height: 1.5;">
                                                    Saludos,<br>
                                                    El equipo de <strong>Dreamsign</strong>
                                                </p>
                    
                                                <hr>
                    
                                                <p style="text-align:center">
                                                    <a href="https://calendar.google.com/calendar/render?action=TEMPLATE&text=El+ABC+del+Marketing+Digital&dates=20250412T150000Z/20250412T160000Z&details=Evento+online+en+Teams.+Conéctate+en+el+siguiente+link:+https://teams.live.com/meet/9326411022672?p=I7alQoiS3zGv0JqRWM&location=Online&sf=true&output=xml" style="
                                                        background-color: #932791;
                                                        border-color: #932791;
                                                        color:#ffffff;
                                                        padding: .75rem 1rem;
                                                        text-decoration:none;
                                                        border-radius:2rem;
                                                        -moz-border-radius:2rem;
                                                        -webkit-border-radius:2rem;"
                                                        >
                                                        ¡Agendar aquí!
                                                    </a>

                                                    <a href="https://teams.live.com/meet/9326411022672?p=I7alQoiS3zGv0JqRWM" style="
                                                        background-color:#1901a0;
                                                        border-color: #1901a0;
                                                        color:#ffffff;
                                                        padding: .75rem 1rem;
                                                        text-decoration:none;
                                                        border-radius:2rem;
                                                        -moz-border-radius:2rem;
                                                        -webkit-border-radius:2rem;"
                                                        >
                                                        ¡Conéctate aquí!
                                                    </a>
                                                </p>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="background-color: #f7f7f7; padding: 10px; text-align: center;">
                                                <p style="font-size: 14px; color: #888888; margin: 0;">Este es un mensaje automático, por favor no respondas a este correo.</p>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </body>
                    </html>
            ';

            $mail->send();

            echo json_encode(["status" => "success", "message" => "Correo enviado exitosamente"]);
        } catch (Exception $e) {
            echo json_encode(["status" => "error", "message" => "No se pudo enviar el correo", "error" => $mail->ErrorInfo]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "No se pudo grabar en BD"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método no permitido"]);
}
?>
