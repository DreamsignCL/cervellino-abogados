import { useEffect, useState } from 'react';

export default function useBlogPosts() {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch('/blog/index.json')
        .then((res) => res.json())
        .then((data) => {
            const sorted = data
            .filter(post => post.published)
            .sort((a, b) => new Date(b.date) - new Date(a.date));
            setPosts(sorted);
            setLoading(false);
        })
        .catch((error) => {
            console.error('Error al cargar los posts:', error);
            setLoading(false);
        });
    }, []);

    return { posts, loading };
}
