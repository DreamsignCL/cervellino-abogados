import React, { useState } from "react";
import { Helmet } from 'react-helmet-async';
import { useForm } from "react-hook-form";
import HeaderSinglePage from '../HeaderSinglePage';
import SocialNetworks from '../assets/components/SocialNetworks';

function Webinar() {
    const { 
        register, 
        handleSubmit, 
        formState: { errors },
        reset, // Agregado para limpiar los campos del formulario después de enviar
    } = useForm();

    const [mensaje, setMensaje] = useState("");
    const [clase, setClase] = useState("");
    const [enviando, setEnviando] = useState(false);

    const enviar = async (data) => {
        setEnviando(true);
        try {
            const googleCalendarUrl = `https://www.google.com/calendar/render?action=TEMPLATE&text=El+ABC+del+Marketing+Digital&dates=20250412T140000Z/20250412T150000Z&details=Hablaremos+sobre+la+importancia+de+la+Web,+Redes+Sociales+y+Posicionamiento+para+tu+negocio.&location=Online&sf=true&output=xml`;

            data.CalendarLink = googleCalendarUrl;

            const response = await fetch("https://dreamsign.cl/send_webinar.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams(data).toString(),
            });

            const result = await response.json();

            // Consola para depuración
            console.log('Resultado recibido del servidor:', result);

            if (result.status === "success") {
                setMensaje("Correo enviado exitosamente");
                setClase("alert-success");
                reset(); // Limpia los campos del formulario
            } else {
                setMensaje(`Error: ${result.message}`);
                setClase("alert-danger");
            }
        } catch (error) {
            setMensaje("Hubo un problema al enviar el correo.");
            setClase("alert-danger");
        } finally {
            setEnviando(false);
        }
    };

    return (
        <>
            <Helmet>
                <title>Dreamsign | Webinar: El ABC del Marketing Digital</title>
                <meta name="description" content="Participa en nuestros webinars enfocados principalmente para emprendedores." />
                <meta name="keywords" content="Webinars, Emprendedores, Aprendizaje" />
                <link rel="canonical" href="https://dreamsign.cl/webinars" />

                <script type="application/ld+json">
                    {`
                        {
                        "@context": "https://schema.org",
                        "@type": "Service",
                        "name": "Webinars",
                        "description": "En esta sección encontrarás los webinars que iremos realizando como Dreamsign.",
                        "provider": {
                            "@type": "Organization",
                            "name": "Dreamsign",
                            "url": "https://www.dreamsign.cl",
                            "logo": {
                            "@type": "ImageObject",
                            "url": "https://www.dreamsign.cl/assets/logo.png",
                            "width": 500,
                            "height": 500
                            },
                            "sameAs": [
                            "https://www.facebook.com/DreamsignCL",
                            "https://x.com/DreamsignCL",
                            "https://www.instagram.com/dreamsigncl/",
                            "https://www.linkedin.com/company/dreamsigncl/"
                            ],
                            "contactPoint": {
                            "@type": "ContactPoint",
                            "telephone": "+56937351500",
                            "contactType": "customer service",
                            "areaServed": "CL",
                            "availableLanguage": "es"
                            }
                        },
                        "areaServed": {
                            "@type": "Country",
                            "name": "Chile"
                        },
                        "serviceType": "Educación, entretención e información",
                        "url": "https://www.dreamsign.cl/webinars"
                        }
                    `}
                    </script>
            </Helmet>

            <HeaderSinglePage />
            <main role="main" className="webinar-page">
                <div className="mask">
                    <div className="container">
                        <div className="row">
                            <div className="col-12 col-md-6">
                                <span className="fs-4">Inscríbete en nuestro webinar</span>
                                <h1 className="text-white">El ABC del Marketing Digital</h1>
                                <p className="fs-5">
                                    Hablaremos sobre la importancia de la Web, las Redes Sociales y el Posicionamiento para tu negocio.
                                </p>
                                <p className="fs-5">
                                    Será el día <strong>12 de Abril a las 11:00 am</strong> vía online.<br />
                                    <strong>¡Y es totalmente gratis!</strong>
                                </p>

                                <hr />

                                <p>Revisa el material de apoyo:</p>
                                <div className="support-documents">
                                    <a className="btn btn-outline-light rounded-pill" href="" target="_blank" rel="noopener noreferrer">Contenido</a>
                                    <a className="btn btn-outline-light rounded-pill" href="" target="_blank" rel="noopener noreferrer">Instrucciones</a>
                                </div>
                            </div>

                            <div className="col-12 col-md-6">
                                {mensaje && (
                                    <div className={`alert ${clase}`} role="status" aria-live="polite">
                                    {mensaje}
                                    </div>
                                )}
                                <p>Los campos con (*) Son obligatorios</p>
                                <form onSubmit={handleSubmit(enviar)} role="form">
                                    <div className="mb-3">
                                        <label htmlFor="Nombre" className="form-label">Nombre*</label>
                                        <input
                                            type="text"
                                            id="Nombre"
                                            className={`form-control rounded-pill ${errors.Nombre ? 'is-invalid' : ''}`}
                                            placeholder="Nombre"
                                            aria-invalid={errors.Nombre ? 'true' : 'false'}
                                            aria-describedby="nombreError"
                                            {...register("Nombre", {
                                                required: "Debes ingresar un nombre",
                                                minLength: { value: 2, message: "No debes usar menos de 2 caracteres" },
                                                maxLength: { value: 50, message: "No debes usar más de 50 caracteres" },
                                            })}
                                        />
                                        {errors.Nombre && <span id="nombreError" className="error-message d-block bg-danger text-white rounded-pill p-2" role="alert">{errors.Nombre.message}</span>}
                                    </div>

                                    <div className="mb-3">
                                        <label htmlFor="Email" className="form-label">Email*</label>
                                        <input
                                            type="email"
                                            id="Email"
                                            className={`form-control rounded-pill ${errors.Email ? 'is-invalid' : ''}`}
                                            placeholder="Email"
                                            aria-invalid={errors.Email ? 'true' : 'false'}
                                            aria-describedby="emailError"
                                            {...register("Email", {
                                                required: "Debes ingresar un email",
                                                pattern: {
                                                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                                    message: "Debes usar una dirección de correo válida",
                                                },
                                            })}
                                        />
                                        {errors.Email && <span id="emailError" className="error-message d-block bg-danger text-white rounded-pill p-2" role="alert">{errors.Email.message}</span>}
                                    </div>

                                    <div className="mb-3">
                                        <label htmlFor="WebEmpresa" className="form-label">Web de tu empresa (solo si tienes)</label>
                                        <input
                                            type="text"
                                            id="WebEmpresa"
                                            className={`form-control rounded-pill ${errors.WebEmpresa ? 'is-invalid' : ''}`}
                                            placeholder="Web empresa"
                                            aria-invalid={errors.WebEmpresa ? 'true' : 'false'}
                                            aria-describedby="webEmpresaError"
                                            {...register("WebEmpresa", {
                                                minLength: { value: 2, message: "No debes usar menos de 2 caracteres" },
                                                maxLength: { value: 100, message: "No debes usar más de 100 caracteres" },
                                            })}
                                        />
                                        {errors.WebEmpresa && <span id="webEmpresaError" className="error-message d-block bg-danger text-white rounded-pill p-2" role="alert">{errors.WebEmpresa.message}</span>}
                                    </div>

                                    <div className="d-grid gap-2">
                                        <button 
                                            className="btn btn-primary rounded-pill" 
                                            type="submit" 
                                            aria-label="Inscribirse al Webinar"
                                            disabled={enviando}>
                                            {enviando ? "Enviando..." : "Inscribirse"}{" "}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
            <footer className="footer-webinar">
                <SocialNetworks />
            </footer>
        </>
    );
}

export default Webinar;
