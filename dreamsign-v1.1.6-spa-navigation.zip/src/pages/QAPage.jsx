import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';
import QualityUnoJPG from '../assets/img/qa1.jpg';
import QualityDosJPG from '../assets/img/qa2.jpg';
import QualityTresJPG from '../assets/img/qa3.jpg';
import QualityCuatroJPG from '../assets/img/qa4.jpg';
import QualityCincoJPG from '../assets/img/qa5.jpg';
import QualitySeisJPG from '../assets/img/qa6.jpg';
import QualitySieteJPG from '../assets/img/qa7.jpg';
import QualityUnoWEBP from '../assets/img/qa1.webp';
import QualityDosWEBP from '../assets/img/qa2.webp';
import QualityTresWEBP from '../assets/img/qa3.webp';
import QualityCuatroWEBP from '../assets/img/qa4.webp';
import QualityCincoWEBP from '../assets/img/qa5.webp';
import QualitySeisWEBP from '../assets/img/qa6.webp';
import QualitySieteWEBP from '../assets/img/qa7.webp';

function QaPage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | Control de Calidad (QA) Profesional</title>
        <meta name="description" content="Asegura el éxito de tus proyectos digitales con nuestro servicio de Quality Assurance basado en ISTQB, accesibilidad y experiencia de usuario." />
        <meta name="keywords" content="Quality Assurance, QA, pruebas de software, ISTQB, accesibilidad, UX, UI, pruebas automatizadas, pruebas funcionales, Dreamsign" />
        <link rel="canonical" href="https://dreamsign.cl/quality-assurance" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Service",
                  "name": "Quality Assurance",
                  "description": "Nuestro servicio de aseguramiento de calidad (QA) Basado en Experiencia, Buenas Prácticas ISTQB, Enfoque en Accesibilidad y UX/UI.",
                  "provider": {
                    "@type": "Organization",
                    "name": "Dreamsign",
                    "url": "https://www.dreamsign.cl",
                    "logo": {
                      "@type": "ImageObject",
                      "url": "https://www.dreamsign.cl/assets/logo.png",
                      "width": 500,
                      "height": 500
                    },
                    "sameAs": [
                      "https://www.facebook.com/DreamsignCL",
                      "https://x.com/DreamsignCL",
                      "https://www.instagram.com/dreamsigncl/",
                      "https://www.linkedin.com/company/dreamsigncl/"
                    ],
                    "contactPoint": {
                      "@type": "ContactPoint",
                      "telephone": "+56937351500",
                      "contactType": "customer service",
                      "areaServed": "CL",
                      "availableLanguage": "es"
                    }
                  },
                  "areaServed": {
                    "@type": "Country",
                    "name": "Chile"
                  },
                  "serviceType": "Pruebas funcionales e integración, automatización y pruebas de rendimiento",
                  "url": "https://www.dreamsign.cl/quality-assurance",
                },
                {
                  "@type": "FAQPage",
                  "mainEntity": [
                    {
                      "@type": "Question",
                      "name": "¿Qué es el servicio de QA de Dreamsign?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Es un servicio integral de aseguramiento de calidad (QA) para software, basado en buenas prácticas como ISTQB, con enfoque en funcionalidad, accesibilidad, rendimiento y experiencia de usuario."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Qué incluye el servicio de QA?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Incluye estrategia de pruebas, pruebas funcionales e integración, automatización, pruebas de rendimiento y seguridad, accesibilidad, UX/UI y consultoría continua."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Por qué es importante realizar QA en mi software?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "El QA permite detectar errores antes de que lleguen al usuario final, garantiza estabilidad, seguridad y una buena experiencia, y reduce costos a largo plazo."
                      }
                    }
                  ]
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <HeaderSinglePage/>

      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="Quality Assurance" />

          <hr/>

          <section className="mt-4">
            <h2>¿Qué es el servicio de QA de Dreamsign?</h2>

            <div className="faq">
              <p className="fs-5">
                Es un servicio integral de aseguramiento de calidad (QA) para software, basado en buenas prácticas como ISTQB, con enfoque en funcionalidad, accesibilidad, rendimiento y experiencia de usuario.
              </p>              

              <h3>¿Por qué es importante realizar QA en mi software?</h3>
              <p>
                El QA permite detectar errores antes de que lleguen al usuario final, garantiza estabilidad, seguridad y una buena experiencia, y reduce costos a largo plazo.
              </p>

              <h3>¿Qué incluye el servicio de QA?</h3>
              <p>
                Incluye estrategia de pruebas, pruebas funcionales e integración, automatización, pruebas de rendimiento y seguridad, accesibilidad, UX/UI y consultoría continua.
              </p>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ QualityUnoWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ QualityUnoJPG }
                    width="100%"
                    height="100%"  
                    alt="Assurance"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Estrategia y Planificación de Pruebas</h2>
                <p>
                  Desarrollamos una estrategia de QA adaptada a los objetivos comerciales y técnicos de cada proyecto. Con metodologías ISTQB, seleccionamos las pruebas más eficaces y los enfoques óptimos para evaluar el producto en cada fase.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ QualityDosWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ QualityDosJPG } 
                    width="100%"
                    height="100%" 
                    alt="Calidad de servicio"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Pruebas Funcionales y de Integración</h2>
                <p>
                  Llevamos a cabo pruebas exhaustivas de funcionalidad e integración, asegurándonos de que cada componente interactúe sin problemas y cumpla con los requisitos especificados, apoyándonos en los principios de análisis de pruebas y diseño de casos de ISTQB.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ QualityTresWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ QualityTresJPG } 
                    width="100%"
                    height="100%" 
                    alt="Automatización de pruebas"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Automatización de Pruebas</h2>
                <p>
                  Aplicamos técnicas avanzadas de automatización para crear scripts reutilizables, acelerando las pruebas de regresión y permitiendo una evaluación continua y rápida de nuevas actualizaciones, bajo estándares ISTQB.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ QualityCuatroWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ QualityCuatroJPG } 
                    width="100%"
                    height="100%" 
                    alt="Rendimiento y seguridad"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Pruebas de Rendimiento y Seguridad</h2>
                <p>
                  Verificamos la estabilidad y seguridad del sistema, utilizando pruebas de rendimiento y evaluación de riesgos para asegurar que el software se mantenga confiable bajo cargas de usuarios reales y proteja la información sensible.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ QualityCincoWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ QualityCincoJPG } 
                    width="100%"
                    height="100%" 
                    alt="Pruebas de accesibilidad"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Pruebas de Accesibilidad y Cumplimiento de Normativas</h2>
                <p>
                  Nos aseguramos de que la aplicación sea accesible para todos los usuarios, incluyendo aquellos con discapacidades, cumpliendo con los estándares de accesibilidad (como WCAG). Esto garantiza que el software no solo sea inclusivo, sino que también cumpla con normativas internacionales.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ QualitySeisWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ QualitySeisJPG } 
                    width="100%"
                    height="100%" 
                    alt="Pruebas de UX"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Pruebas de UX y UI</h2>
                <p>
                  Evaluamos tanto la experiencia de usuario (UX) como la interfaz de usuario (UI), para garantizar que el diseño sea intuitivo, atractivo y fácil de usar. Mediante pruebas de usabilidad y revisiones de diseño, optimizamos la interfaz para asegurar una experiencia coherente y satisfactoria en todas las plataformas.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ QualitySieteWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ QualitySieteJPG } 
                    width="100%"
                    height="100%" 
                    alt="Mejora continua"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Mejora Continua y Consultoría en QA</h2>
                <p>
                  Implementamos procesos de mejora continua y optimización, evaluando y ajustando nuestros métodos con cada proyecto, según las recomendaciones de ISTQB, para maximizar la calidad y eficiencia del proceso de QA.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
              <p className="fs-5 text-center">
                  Nuestro servicio de QA no solo garantiza la funcionalidad y seguridad de tu aplicación, sino que también asegura una experiencia de usuario de alto nivel y un diseño accesible. Con este enfoque integral, te ayudamos a ofrecer productos de software que cumplen con las expectativas de todos los usuarios, creando valor y minimizando riesgos.
              </p>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default QaPage