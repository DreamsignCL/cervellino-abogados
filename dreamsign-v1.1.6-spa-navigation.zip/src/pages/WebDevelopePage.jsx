import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';
import PrototipeJPG from '../assets/img/prototipe-figma.jpg';
import WebDevelopeJPG from '../assets/img/web-develope.jpg';
import PrototipeWEBP from '../assets/img/prototipe-figma.webp';
import WebDevelopeWEBP from '../assets/img/web-develope.webp';
import WebServices from '../assets/components/WebServices';

function WebDevelopePage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | Desarrollo web</title>
        <meta name="description" content="Diseñamos y desarrollamos sitios web modernos, funcionales y adaptados a tus necesidades." />
        <meta name="keywords" content="Prototipo, Figma, Desarrollo web, Web apps" />
        <link rel="canonical" href="https://dreamsign.cl/web-development" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "name": "Desarrollo web",
              "description": "Diseñamos y desarrollamos sitios web modernos, funcionales y adaptados a tus necesidades.",
              "provider": {
                "@type": "Organization",
                "name": "Dreamsign",
                "url": "https://www.dreamsign.cl",
                "logo": {
                  "@type": "ImageObject",
                  "url": "https://www.dreamsign.cl/assets/logo.png",
                  "width": 500,
                  "height": 500
                },
                "sameAs": [
                  "https://www.facebook.com/DreamsignCL",
                  "https://x.com/DreamsignCL",
                  "https://www.instagram.com/dreamsigncl/",
                  "https://www.linkedin.com/company/dreamsigncl/"
                ],
                "contactPoint": {
                  "@type": "ContactPoint",
                  "telephone": "+56937351500",
                  "contactType": "customer service",
                  "areaServed": "CL",
                  "availableLanguage": "es"
                }
              },
              "areaServed": {
                "@type": "Country",
                "name": "Chile"
              },
              "serviceType": "Prototipado, desarrollo web y apps",
              "url": "https://www.dreamsign.cl/web-development"
            }
          `}
        </script>
      </Helmet>
      <HeaderSinglePage/>
      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="Desarrollo web" />
          <hr/>
          
          <p className="fs-5">
            Diseñamos y desarrollamos sitios web modernos, funcionales y adaptados a tus necesidades. Desde interfaces atractivas hasta programación sólida, creamos experiencias web que no solo impresionan, sino que también logran los objetivos comerciales de tu empresa.
          </p>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ PrototipeWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ PrototipeJPG }
                    width="100%"
                    height="100%"  
                    alt="Prototipado"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Prototipado</h2>
                <p>
                  Antes de partir con la codificación es necesario comenzar con el diseño y que mejor que prototipar tu proyecto. El prototipo es un diseño de tu aplicativo digital previo al desarrollo a nivel de código del mismo, el cual tiene como objetivo poder tener un aproximado casi exacto de cómo quedará tu proyecto antes de empezar a programar.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ WebDevelopeWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ WebDevelopeJPG } 
                    width="100%"
                    height="100%" 
                    alt="Desarrollo web"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Desarrollo web</h2>
                <p>
                  Desarrollamos soluciones digitales de acuerdo a tus necesidades. ¿Necesitas una web para tu negocio?, ahora creció y ¿deseas convertirla en un <strong>E-Commerce</strong>? No hay problema, tenemos soluciones para todas las necesidades y contamos con la expertiz para generar desarrollos escalables al nivel de tus ideas.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="subtitle">¿Qué tramo se ajusta a tu proyecto?</h2>
            <WebServices/>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default WebDevelopePage
