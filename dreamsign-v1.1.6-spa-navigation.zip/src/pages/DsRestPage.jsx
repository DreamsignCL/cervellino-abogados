import React, { useState, useEffect, useRef } from "react"
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faTimes, faCircleXmark, faCircleCheck, faLocationDot, faMobileScreenButton, faEnvelope } from '@fortawesome/free-solid-svg-icons';
import LogoDsRest  from '../assets/img/logo-dsrest.svg';
import DsRestBackgroundAnimation  from '../assets/components/DsRestBackgroundAnimation';
import SocialNetworks from '../assets/components/SocialNetworks';
import ContactForm from '../assets/components/ContactForm';
import Model3D from "../assets/components/Model3D";
import MultipleMobileDsRest from '../assets/img/multiple-mobile-dsrest.png';
import QRDsRest from '../assets/img/qrcode-solid.svg';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import '@/assets/scss/dsrest-style.scss';

function DsRestPage() {
    const [scroll, setScroll] = useState(false);
    const [isActive, setIsActive] = useState(false);
    const menuRef = useRef(null);
    const location = useLocation();
    const navigate = useNavigate();

    const toggleNav = () => {
        setIsActive(!isActive);
    };

    const handleInternalNavigation = () => {
        setIsActive(false);
    };

    const handleHomeSectionNavigation = (sectionId, event) => {
        event.preventDefault();
        setIsActive(false);
        navigate(`/#${sectionId}`);
    };

    useEffect(() => {
        if (isActive && menuRef.current) {
            menuRef.current.querySelector("a")?.focus();
        }
    }, [isActive]);

    useEffect(() => {
        if (!location.hash) return;

        const sectionId = decodeURIComponent(location.hash.slice(1));
        requestAnimationFrame(() => {
            document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth" });
        });
    }, [location.pathname, location.hash]);
        
    useEffect(() => {
        const handleScroll = () => setScroll(window.scrollY > 10);
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    var settings = {
        dots: true,
        infinite: false,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 3,
        responsive: [
            {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
            }
        ]
    };

    return (
        <>
            <Helmet>
                <title>DSRest - La solución para tu negocio</title>
                <meta name="description" content="Contrata con nosotros la nueva app de Dreamsign para restaurantes, cafeterías, bares, restobares y cualquier local de comida" />
                <meta name="keywords" content="Restaurant, Menu digital, Administración, Gestión" />
                <link rel="canonical" href="https://dreamsign.cl/dsrest" />
                <link rel="preconnect" href="https://fonts.googleapis.com" />
                <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
                <link href="https://fonts.googleapis.com/css2?family=Archivo+Black&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet" />

                <script type="application/ld+json">
                {`
                    {
                    "@context": "https://schema.org",
                    "@type": "Service",
                    "name": "DSRest",
                    "description": "Contrata con nosotros la nueva app de Dreamsign para restaurantes, cafeterías, bares, restobares y cualquier local de comida.",
                    "provider": {
                        "@type": "Organization",
                        "name": "Dreamsign",
                        "url": "https://www.dreamsign.cl",
                        "logo": {
                        "@type": "ImageObject",
                        "url": "https://www.dreamsign.cl/assets/logo.png",
                        "width": 500,
                        "height": 500
                        },
                        "sameAs": [
                        "https://www.facebook.com/DreamsignCL",
                        "https://x.com/DreamsignCL",
                        "https://www.instagram.com/dreamsigncl/",
                        "https://www.linkedin.com/company/dreamsigncl/"
                        ],
                        "contactPoint": {
                        "@type": "ContactPoint",
                        "telephone": "+56937351500",
                        "contactType": "customer service",
                        "areaServed": "CL",
                        "availableLanguage": "es"
                        }
                    },
                    "areaServed": {
                        "@type": "Country",
                        "name": "Chile"
                    },
                    "serviceType": "Gestión de local, administración de platos y mesas",
                    "url": "https://www.dreamsign.cl/dsrest"
                    }
                `}
                </script>
            </Helmet>

            <div className="dsrest-page">
                <header className={scroll ? "header-dsrest-page scrolled" : "header-dsrest-page"}>
                    <div className="container">
                        <div className="d-flex justify-content-between align-items-center">
                            <Link to="/" aria-label="Ir a la página de inicio">
                                <img src={LogoDsRest} width="100%" height="100%" alt="Logotipo de dsRest"></img>
                            </Link>

                            <div ref={menuRef}>
                                <button 
                                    className="trigger-menu d-md-none" 
                                    onClick={toggleNav}
                                    type="button" 
                                    aria-label="Abrir menú">
                                    <FontAwesomeIcon icon={faBars} aria-hidden="true" size="2x" />
                                </button>
                    
                                <nav className="main-menu-desktop d-none d-md-block" aria-label="Navegación principal">
                                    <ul>
                                        <li>
                                            <Link to="/" title="Volver al inicio" onClick={handleInternalNavigation}>Inicio</Link>
                                        </li>
                                        <li>
                                            <Link to="/#services" title="Ver nuestros servicios" onClick={(event) => handleHomeSectionNavigation("services", event)}>Servicios</Link>
                                        </li>
                                        <li>
                                            <Link to="/#about_us" title="Conoce sobre nosotros" onClick={(event) => handleHomeSectionNavigation("about_us", event)}>Nosotros</Link>
                                        </li>
                                        <li>
                                            <Link to="/#clients" title="Descubre nuestros clientes" onClick={(event) => handleHomeSectionNavigation("clients", event)}>Clientes</Link>
                                        </li>
                                        <li>
                                            <a href="#contact" title="Contáctanos para mayor información">Contacto</a>
                                        </li>
                                    </ul>
                                </nav>
                    
                                <div 
                                    id="menu_mobile" 
                                    className="main-menu-mobile"
                                    tabIndex="-1" 
                                    aria-labelledby="menuMobileLabel" 
                                    aria-hidden={!isActive}
                                    style={{ display: isActive ? "block" : "none" }}>
                    
                                    <div className="menu-content">
                                        <div className="d-flex justify-content-between">
                                            <h4 id="menuMobileLabel" className="text-primary">Conoce nuestras secciones</h4>
                                            <button 
                                                className="close-menu" 
                                                onClick={toggleNav}
                                                type="button" 
                                                aria-label="Cerrar menú">
                                                <FontAwesomeIcon icon={faTimes} aria-hidden="true" size="2x" />
                                            </button>
                                        </div>
                                        
                                        <nav aria-label="Navegación principal">
                                            <ul>
                                                <li>
                                                    <Link to="/" title="Volver al inicio" onClick={handleInternalNavigation}>Inicio</Link>
                                                </li>
                                                <li>
                                                    <Link to="/design" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Diseño corporativo</Link>
                                                </li>
                                                <li>
                                                    <Link to="/web-development" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Desarrollo web</Link>
                                                </li>
                                                <li>
                                                    <Link to="/hosting" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Hosting</Link>
                                                </li>
                                                <li>
                                                    <Link to="/seo-marketing" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>SEO / SEM</Link>
                                                </li>
                                                <li>
                                                    <Link to="/user-experience" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Diseño UX</Link>
                                                </li>
                                                <li>
                                                    <Link to="/quality-assurance" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Quality Assurance</Link>
                                                </li>
                                                <li>
                                                    <Link to="/accessibility" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Accesibilidad</Link>
                                                </li>
                                                <li>
                                                    <a href="#contact" title="Contáctanos para mayor información">Contacto</a>
                                                </li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <main role="main">
                    <section className="welcome">
                        <div className="container">
                            <div className="row">
                                <div className="col-12 col-md-6">
                                    <h1>¿Buscas una mejor manera de mostrar el menú de tu Restaruant?</h1>
                                    <h2>¡dsRest es tu solución!</h2>
                                </div>
                                <div className="col-12 col-md-6">
                                    <div className="model3D">
                                        <Model3D />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <DsRestBackgroundAnimation />
                    </section>

                    <section className="descriptions1">
                        <div className="container">
                            <div className="row">
                                <div className="col-12 col-md-6">
                                    <h2>Crea o modifica tu menú a solo un click de distancia</h2>
                                    <p>
                                        Como administrador, sabes que cada minuto cuenta. Nuestra aplicación está diseñada para simplificar y agilizar la gestión de tu restaurante, permitiéndote:
                                        Actualizar menús en tiempo real: Modifica precios, añade o elimina platos y adapta tu oferta al instante.
                                    </p>
                                </div>
                                <div className="col-12 col-md-6"></div>
                            </div>
                        </div>
                    </section>

                    <section className="third">
                        <div className="container">
                            <div className="row">
                                <div className="col-12 col-md-6">
                                    <figure className="figure smartphone">
                                        <picture>
                                            <source srcSet={ MultipleMobileDsRest } type="image/webp" />
                                            <img
                                                src={ MultipleMobileDsRest }
                                                width="100%"
                                                height="100%" 
                                                alt="Multiples Mobile con la app" />
                                        </picture>
                                    </figure>
                                </div>
                                <div className="col-12 col-md-6 d-flex align-items-center">
                                    <div className="content">
                                        <h2>Agiliza las decisiones de tus clientes al ordenar</h2>
                                        <p>
                                            Muestra todos tus platos de forma clara y accesible desde cualquier dispositivo.<br/>Con dsRest, tus clientes podrán explorar fácilmente tu menú en línea y tomar decisiones más rápidas y acertadas al momento de elegir qué comer.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section className="fourth">
                        <div className="container">
                            <div className="row">
                                <div className="col-12 col-md-6">
                                    <h2>Imprime y/o comparte tu código QR</h2>
                                    <p>
                                        Puedes generar un código QR único para tu menú, que podrás imprimir y colocar en mesas, vitrinas o cualquier lugar visible de tu establecimiento. Este código permite a tus clientes acceder al menú actualizado en tiempo real desde sus dispositivos móviles, sin necesidad de contacto físico
                                    </p>
                                </div>
                                <div className="col-12 col-md-6">
                                    <img src={QRDsRest} width="100%" height="100%" alt="" />
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className="prices d-none">
                        <DsRestBackgroundAnimation/>
                        <div className="container">
                            <h2>Elige el plan que más te acomode</h2>

                            <Slider className="d-md-none" {...settings}>
                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Carta</h4>
                                        <h5>$9.990 CLP / $10 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Administrador de Menú digital</li>
                                            <li>Creación de platos</li>
                                            <li>Edición de perfil</li>
                                            <li>Exportación de Menú digital QR</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>

                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Básico</h4>
                                        <h5>$19.900 CLP / $20 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Todo lo del plan Admin</li>
                                            <li>Creación de garzones</li>
                                            <li>Mesas</li>
                                            <li>Escritorio garzón</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>

                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Avanzado</h4>
                                        <h5>$29.900 CLP / $30 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Todo lo del plan Básico</li>
                                            <li>Crear zonas</li>
                                            <li>Asignar mesas</li>
                                            <li>Asignar garzones</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>

                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Premium</h4>
                                        <h5>$39.900 CLP / $40 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Todo lo del plan Avanzado</li>
                                            <li>Gestión de comenzales (pago individual por mesa)</li>
                                            <li>Futuras integraciones</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>
                            </Slider>

                            <div className="price-elements d-none d-md-flex">
                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Admin</h4>
                                        <h5>$9.990 CLP / $10 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Administrador de Menú digital</li>
                                            <li>Creación de platos</li>
                                            <li>Edición de perfil</li>
                                            <li>Exportación de Menú digital QR</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>

                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Básico</h4>
                                        <h5>$19.900 CLP / $20 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Todo lo del plan Admin</li>
                                            <li>Creación de garzones</li>
                                            <li>Mesas</li>
                                            <li>Escritorio garzón</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>

                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Avanzado</h4>
                                        <h5>$29.900 CLP / $30 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Todo lo del plan Básico</li>
                                            <li>Crear zonas</li>
                                            <li>Asignar mesas</li>
                                            <li>Asignar garzones</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>

                                <div className="card-price">
                                    <div className="header">
                                        <h4>Plan Premium</h4>
                                        <h5>$39.900 CLP / $40 USD</h5>
                                    </div>
                                    <div className="body">
                                        <ul>
                                            <li>Todo lo del plan Avanzado</li>
                                            <li>Gestión de comenzales (pago individual por mesa)</li>
                                            <li>Futuras integraciones</li>
                                        </ul>
                                    </div>
                                    <div className="footer">
                                        <a className="btn btn-warning" href="" target="_blank">¡Contratar ahora!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className="plans-compare">
                        <div className="container">
                            <h2>Comparación de planes</h2>
                            <p>Conoce en detalle cada uno de nuestros planes para que tu elección sea la mejor!</p>

                            <div className="table-responsive">
                                <table className="table table-sm table-striped text-start">
                                    <thead>
                                        <tr>
                                            <th>Funciones</th>
                                            <th>Carta</th>
                                            <th>Básico</th>
                                            <th>Avanzado</th>
                                            <th>Premium</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Crear y editar platos</td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Editar perfil administrador</td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Crear garzones</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Crear mesas</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Escritorio del garzón</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Crear zonas</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Asignar mesas a zonas</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Asignar garzones a mesas</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Gestión de comensales (pago individual por mesa)</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Soporte prioritario</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Integraciones futuras</td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="xmark" icon={faCircleXmark} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Actualizaciones automáticas</td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                            <td>
                                                <FontAwesomeIcon className="check" icon={faCircleCheck} aria-hidden="true" size="1x" />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </section>
                </main>
                <footer>
                    <div id="contact" className="footer-content">
                        <div className="container">
                            <div className="row">
                                <div className="col-12 col-md-6 order-2 order-md-1">
                                    <div className="how-contact">
                                        <h3>Elige cómo contactarnos</h3>
                                        <SocialNetworks />
                                    </div>

                                    <hr/>

                                    <ul className="other-contact">
                                        <li>
                                            <h4>Dirección:</h4>
                                            <a 
                                                href="https://maps.app.goo.gl/Bw9UFmAf6VDUpvah8" 
                                                target="_blank" 
                                                aria-label="Ver dirección en Google Maps"
                                                rel="noopener noreferrer">
                                                <FontAwesomeIcon icon={faLocationDot} aria-hidden="true" />
                                                <span>Badajoz 100, Oficina 1014, Las Condes, Región Metropolitana</span>
                                            </a>
                                        </li>
                                        <li>
                                            <h4>Ventas:</h4>
                                            <p>
                                                <a href="tel:+56937351500" target="_blank" aria-label="Llamar a ventas al (+569) 3735 1500">
                                                    <FontAwesomeIcon icon={faMobileScreenButton} aria-hidden="true" />
                                                    <span>(+569) 3735 1500</span>
                                                </a>
                                            </p>
                                            <p>
                                                <a href="mailto:ventas@dreamsign.cl" target="_blank">
                                                    <FontAwesomeIcon icon={faEnvelope} aria-hidden="true" />
                                                    <span>ventas@dreamsign.cl</span>
                                                </a>
                                            </p>
                                        </li>
                                    </ul>
                                </div>
                                <div className="col-12 col-md-6 order-1 order-md-2">
                                    <h4>Resolvemos todas tus dudas. ¡Escríbenos!</h4>
                                    <ContactForm/>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </>
    );
}

export default DsRestPage
