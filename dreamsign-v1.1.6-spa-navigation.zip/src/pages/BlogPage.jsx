import { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import useBlogPosts from '../hooks/useBlogPosts';
import BlogList from '../assets/components/BlogList';
import Footer from '../Footer';

function BlogPage() {
    const { posts, loading } = useBlogPosts();

    const [searchTerm, setSearchTerm] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('');
    const [currentPage, setCurrentPage] = useState(1);

    const postsPerPage = 6;

    const uniqueCategories = [...new Set(posts.flatMap(p => p.categories || []))];

    const filteredPosts = posts.filter(post => {
        const matchesSearch =
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.description.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesCategory = categoryFilter
        ? post.categories?.includes(categoryFilter)
        : true;

        return matchesSearch && matchesCategory;
    });

    const totalPages = Math.ceil(filteredPosts.length / postsPerPage);

    const currentPosts = filteredPosts.slice(
        (currentPage - 1) * postsPerPage,
        currentPage * postsPerPage
    );

    const handlePageChange = (page) => {
        if (page >= 1 && page <= totalPages) {
        setCurrentPage(page);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };

    // Reset page cuando cambian los filtros o búsqueda
    const handleSearchChange = (e) => {
        setSearchTerm(e.target.value);
        setCurrentPage(1);
    };

    const handleCategoryChange = (e) => {
        setCategoryFilter(e.target.value);
        setCurrentPage(1);
    };

    return (
        <>
            <Helmet>
                <title>Dreamsign | Blog</title>
                <meta name="description" content="Entérate de lo último en diseño, desarrollo web, y novedades de Dreamsign. Consejos, noticias y mucho más en nuestro blog oficial." />
                <meta name="keywords" content="blog diseño, blog desarrollo web, dreamsign, tecnología, noticias, UX, UI, programación" />
                <link rel="canonical" href="https://dreamsign.cl/blog" />

                {/* Open Graph */}
                <meta property="og:title" content="Blog | Dreamsign" />
                <meta property="og:description" content="Artículos, casos de éxito y consejos sobre diseño, desarrollo web, marketing y más." />
                <meta property="og:url" content="https://dreamsign.cl/blog" />
                <meta property="og:image" content="https://dreamsign.cl/assets/default-og.jpg" />
                <meta property="og:type" content="website" />

                {/* Twitter */}
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:title" content="Blog | Dreamsign" />
                <meta name="twitter:description" content="Artículos, casos de éxito y consejos sobre diseño, desarrollo web, marketing y más." />
                <meta name="twitter:image" content="https://dreamsign.cl/assets/default-og.jpg" />

                
                {/* SEO Avanzado: Schema para blog */}
                <script type="application/ld+json">
                    {`
                        {
                            "@context": "https://schema.org",
                            "@type": "Blog",
                            "name": "Dreamsign Blog",
                            "url": "https://www.dreamsign.cl/blog",
                            "description": "Blog oficial de Dreamsign con noticias, recursos y novedades sobre diseño y desarrollo web.",
                            "publisher": {
                                "@type": "Organization",
                                "name": "Dreamsign",
                                "logo": {
                                    "@type": "ImageObject",
                                    "url": "https://www.dreamsign.cl/assets/logo.png"
                                }
                            }
                        }
                    `}
                </script>
            </Helmet>

            <HeaderSinglePage/>
            
            <main role="main" className="single-page">
                <div className="container">
                    <MainHeader pageTitle="Blog" />

                    <hr/>
                    
                    <p className="fs-5">
                        Entérate de las últimas novedades en el mundo del diseño y la tecnología; además, conoce nuevos detalles relacionados a Dreamsign!
                    </p>

                    {/* Filtros */}
                    <div className="row mb-4">
                        <div className="col-md-6 mb-2">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Buscar por título o descripción..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                        </div>
                        <div className="col-md-6 mb-2">
                        <select
                            className="form-select"
                            value={categoryFilter}
                            onChange={e => setCategoryFilter(e.target.value)}
                        >
                            <option value="">Todas las categorías</option>
                            {uniqueCategories.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                            ))}
                        </select>
                        </div>
                    </div>

                    {/* Lista de posts */}
                    {loading ? (
                        <p>Cargando...</p>
                    ) : filteredPosts.length > 0 ? (
                        <>
                        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                            <BlogList posts={currentPosts} />
                        </div>

                        {/* Paginación */}
                        <nav className="mt-5 d-flex justify-content-center">
                            <ul className="pagination">
                            <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                                <button className="page-link" onClick={() => handlePageChange(currentPage - 1)}>
                                Anterior
                                </button>
                            </li>

                            {Array.from({ length: totalPages }, (_, index) => index + 1).map((pageNum) => (
                                <li
                                key={pageNum}
                                className={`page-item ${currentPage === pageNum ? 'active' : ''}`}
                                >
                                <button className="page-link" onClick={() => handlePageChange(pageNum)}>
                                    {pageNum}
                                </button>
                                </li>
                            ))}

                            <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                                <button className="page-link" onClick={() => handlePageChange(currentPage + 1)}>
                                Siguiente
                                </button>
                            </li>
                            </ul>
                        </nav>
                        </>
                    ) : (
                        <div className="text-center text-muted py-5">
                        <h4>No se encontraron publicaciones.</h4>
                        </div>
                    )}
                </div>
            </main>
            <Footer/>
        </>
    );
}

export default BlogPage
