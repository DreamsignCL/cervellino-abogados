import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';
import AccessUnoJPG from '../assets/img/access1.jpg';
import AccessDosJPG from '../assets/img/access2.jpg';
import AccessTresJPG from '../assets/img/access3.jpg';
import AccessUnoWEBP from '../assets/img/access1.webp';
import AccessDosWEBP from '../assets/img/access2.webp';
import AccessTresWEBP from '../assets/img/access3.webp';

function AccessibilityPage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | Accesibilidad Web</title>
        <meta name="description" content="Creamos sitios web accesibles, optimizados para SEO e inclusivos para todas las personas. Cumple con estándares internacionales y mejora la experiencia del usuario." />
        <meta name="keywords" content="accesibilidad web, inclusión digital, SEO, WCAG, Dreamsign" />
        <link rel="canonical" href="https://dreamsign.cl/accessibility" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Service",
                  "name": "Accesibilidad",
                  "description": "Garantizamos que tu sitio web sea accesible para todas las personas, incluidas aquellas con discapacidades. Implementamos mejores prácticas de accesibilidad para asegurar una experiencia inclusiva y conforme a estándares internacionales.",
                  "provider": {
                    "@type": "Organization",
                    "name": "Dreamsign",
                    "url": "https://www.dreamsign.cl",
                    "logo": {
                      "@type": "ImageObject",
                      "url": "https://www.dreamsign.cl/assets/logo.png",
                      "width": 500,
                      "height": 500
                    },
                    "sameAs": [
                      "https://www.facebook.com/DreamsignCL",
                      "https://x.com/DreamsignCL",
                      "https://www.instagram.com/dreamsigncl/",
                      "https://www.linkedin.com/company/dreamsigncl/"
                    ],
                    "contactPoint": {
                      "@type": "ContactPoint",
                      "telephone": "+56937351500",
                      "contactType": "customer service",
                      "areaServed": "CL",
                      "availableLanguage": "es"
                    }
                  },
                  "areaServed": {
                    "@type": "Country",
                    "name": "Chile"
                  },
                  "serviceType": "Prácticas accesibles, contraste de colores y compatibilidad con lectores de pantalla",
                  "url": "https://www.dreamsign.cl/accessibility",
                },
                {
                  "@type": "FAQPage",
                  "mainEntity": [
                    {
                      "@type": "Question",
                      "name": "¿Qué es la accesibilidad web?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "La accesibilidad web es el diseño y desarrollo de sitios que pueden ser utilizados por todas las personas, incluyendo aquellas con discapacidades visuales, auditivas, motoras o cognitivas."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Por qué es importante tener un sitio web accesible?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Un sitio accesible mejora la experiencia del usuario, cumple con normativas legales y amplía el alcance de tu marca. Además, tiene un impacto positivo en el posicionamiento SEO."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Qué servicios ofrece Dreamsign en accesibilidad?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Ofrecemos la implementación de prácticas accesibles como navegación por teclado, contraste de colores, y compatibilidad con lectores de pantalla, cumpliendo con estándares internacionales como WCAG."
                      }
                    }
                  ]
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <HeaderSinglePage/>

      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="Accesibilidad Web" />

          <hr/>

          <section className="mt-4">
            <h2>¿Qué es la accesibilidad web?</h2>

            <div className="faq">
              <p className="fs-5">
                La accesibilidad web es el diseño y desarrollo de sitios que pueden ser utilizados por todas las personas, incluyendo aquellas con discapacidades visuales, auditivas, motoras o cognitivas.
              </p>

              <h3>¿Por qué es importante tener un sitio web accesible?</h3>
              <p>
                Un sitio accesible mejora la experiencia del usuario, cumple con normativas legales y amplía el alcance de tu marca. Además, tiene un impacto positivo en el posicionamiento SEO.
              </p>

              <h3>¿Qué servicios ofrece Dreamsign en accesibilidad?</h3>
              <p>
                Ofrecemos la implementación de prácticas accesibles como navegación por teclado, contraste de colores, y compatibilidad con lectores de pantalla, cumpliendo con estándares internacionales como WCAG.
              </p>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ AccessUnoWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ AccessUnoJPG }
                    width="100%"
                    height="100%"  
                    alt="Ejemplo de personas visitando una web con accesibilidad"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Adaptación para Lectores de Pantalla</h2>
                <p>
                  Configuramos el sitio para que sea interpretado correctamente por tecnologías de asistencia, permitiendo a usuarios con discapacidades visuales acceder al contenido sin problemas.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ AccessDosWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ AccessDosJPG }
                    width="100%"
                    height="100%"  
                    alt="Ejemplo de inclusión ante las personas discapacitadas"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Contraste y Color Accesible</h2>
                <p>
                  Ajustamos colores y contrastes para que el sitio sea legible y fácil de navegar para personas con dificultades visuales, asegurando una experiencia óptima para todos los usuarios.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ AccessTresWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ AccessTresJPG } 
                    width="100%"
                    height="100%" 
                    alt="Ejemplo de iconos accesibles"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Navegación Simplificada</h2>
                <p>
                  Optimización de la estructura del sitio para facilitar el uso mediante teclado y otros dispositivos. Esto permite que personas con limitaciones motoras naveguen de manera fluida y cómoda.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default AccessibilityPage
