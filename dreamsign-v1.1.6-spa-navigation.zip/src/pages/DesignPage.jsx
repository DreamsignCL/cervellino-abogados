import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';
import LogoDesignJPG from '../assets/img/logo-design.jpg';
import PaperDesignJPG from '../assets/img/papeleria-corporativa.jpg';
import TradeMarkDesignJPG from '../assets/img/manual-marca.jpg';
import LogoDesignWEBP from '../assets/img/logo-design.webp';
import PaperDesignWEBP from '../assets/img/papeleria-corporativa.webp';
import TradeMarkDesignWEBP from '../assets/img/manual-marca.webp';

function DesignPage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | Diseño corporativo</title>
        <meta name="description" content="Construimos identidad para tu marca. Diseñamos logotipos, papelería corporativa, manuales de marca y mucho más para empresas profesionales." />
        <meta name="keywords" content="Diseño corporativo, Diseño de logotipos, Identidad de marca, Papelería empresarial, Manual de marca" />
        <link rel="canonical" href="https://dreamsign.cl/design" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "name": "Diseño Corporativo",
              "description": "Ofrecemos servicios de diseño corporativo como logotipos, papelería, manuales de marca y branding integral para empresas.",
              "provider": {
                "@type": "Organization",
                "name": "Dreamsign",
                "url": "https://www.dreamsign.cl",
                "logo": {
                  "@type": "ImageObject",
                  "url": "https://www.dreamsign.cl/assets/logo.png",
                  "width": 500,
                  "height": 500
                },
                "sameAs": [
                  "https://www.facebook.com/DreamsignCL",
                  "https://x.com/DreamsignCL",
                  "https://www.instagram.com/dreamsigncl/",
                  "https://www.linkedin.com/company/dreamsigncl/"
                ],
                "contactPoint": {
                  "@type": "ContactPoint",
                  "telephone": "+56937351500",
                  "contactType": "customer service",
                  "areaServed": "CL",
                  "availableLanguage": "es"
                }
              },
              "areaServed": {
                "@type": "Country",
                "name": "Chile"
              },
              "serviceType": "Diseño de logotipos, papelería corporativa y branding",
              "url": "https://www.dreamsign.cl/design"
            }
          `}
        </script>
      </Helmet>

      <HeaderSinglePage/>

      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="Diseño Corporativo" />
          
          <hr/>
          
          <p className="fs-5">
            Construimos identidades visuales que reflejan los valores y personalidad de tu marca, logrando una conexión sólida con tu audiencia. Desarrollamos elementos únicos y profesionales que permiten a tu empresa destacar en cada punto de contacto con el cliente.
          </p>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ LogoDesignWEBP } type="image/webp" />
                  <img 
                    className="img-fluid rounded" 
                    src={ LogoDesignJPG }
                    width="100%"
                    height="100%"  
                    alt="Diseño de logotipo"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Logotipos</h2>
                <p>
                  Creamos logotipos originales y memorables, adaptables a diversos formatos y plataformas. Cada logotipo está diseñado para reflejar la esencia de la marca y facilitar el reconocimiento inmediato en todos los canales.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ PaperDesignWEBP } type="image/webp" />
                  <img 
                    className="img-fluid rounded" 
                    src={ PaperDesignJPG }
                    width="100%"
                    height="100%"  
                    alt="Diseño de papelería"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Papelería</h2>
                <p>
                  Diseñamos tarjetas, hojas membretadas, sobres y otros elementos de comunicación, fortaleciendo la identidad visual en cada interacción con el cliente. Estos materiales proyectan profesionalismo y consistencia en cada detalle.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ TradeMarkDesignWEBP } type="image/webp" />
                  <img 
                    className="img-fluid rounded" 
                    src={ TradeMarkDesignJPG }
                    width="100%"
                    height="100%"  
                    alt="Diseño de manual de marca"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Manual de marca</h2>
                <p>
                  Documentamos los elementos clave de la marca (colores, tipografía y estilos), asegurando una representación coherente en todas las plataformas. Esto ayuda a mantener la identidad y facilita su aplicación correcta.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default DesignPage
