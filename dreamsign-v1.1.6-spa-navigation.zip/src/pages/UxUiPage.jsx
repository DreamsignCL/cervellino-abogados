import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';
import WireframingJPG from '../assets/img/wireframing.jpg';
import UxDesignJPG from '../assets/img/ux-ui.jpg';
import UsabilityTestJPG from '../assets/img/usability-test.jpg';
import WireframingWEBP from '../assets/img/wireframing.webp';
import UxDesignWEBP from '../assets/img/ux-ui.webp';
import UsabilityTestWEBP from '../assets/img/usability-test.webp';

function UxUiPage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | User Experience & User Interface</title>
        <meta name="description" content="Conoce nuestro servicio de UX UI que permitirá que tus desarrollos digitales cumplan todos los estándares de calidad que tus clientes requieren." />
        <meta name="keywords" content="UX, UI, diseño de experiencia de usuario, interfaces intuitivas, wireframing, prototipado, Dreamsign" />
        <link rel="canonical" href="https://dreamsign.cl/user-experience" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Service",
                  "name": "User Experience & User Interface",
                  "description": "Diseñamos experiencias y interfaces intuitivas que aumentan la satisfacción de los usuarios. Nos centramos en crear interfaces atractivas y usables, aplicando principios de diseño centrados en el usuario para garantizar accesibilidad y efectividad en cada interacción.",
                  "provider": {
                    "@type": "Organization",
                    "name": "Dreamsign",
                    "url": "https://www.dreamsign.cl",
                    "logo": {
                      "@type": "ImageObject",
                      "url": "https://www.dreamsign.cl/assets/logo.png",
                      "width": 500,
                      "height": 500
                    },
                    "sameAs": [
                      "https://www.facebook.com/DreamsignCL",
                      "https://x.com/DreamsignCL",
                      "https://www.instagram.com/dreamsigncl/",
                      "https://www.linkedin.com/company/dreamsigncl/"
                    ],
                    "contactPoint": {
                      "@type": "ContactPoint",
                      "telephone": "+56937351500",
                      "contactType": "customer service",
                      "areaServed": "CL",
                      "availableLanguage": "es"
                    }
                  },
                  "areaServed": {
                    "@type": "Country",
                    "name": "Chile"
                  },
                  "serviceType": "Investigación de Usuarios, wireframing y prototipado y pruebas de Usabilidad",
                  "url": "https://www.dreamsign.cl/user-experience",
                },
                {
                  "@type": "FAQPage",
                  "mainEntity": [
                    {
                      "@type": "Question",
                      "name": "¿Qué es UX/UI?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "UX (User Experience) se enfoca en cómo los usuarios interactúan con un producto digital, mientras que UI (User Interface) se centra en el diseño visual y la interacción con los elementos. Juntos crean experiencias digitales funcionales y atractivas."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Por qué es importante el diseño UX/UI?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Un buen diseño UX/UI mejora la satisfacción del usuario, facilita la navegación, reduce la tasa de rebote y aumenta las conversiones. Es clave para destacar frente a la competencia digital."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Qué servicios ofrece Dreamsign en UX/UI?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Ofrecemos investigación de usuarios, wireframing, prototipado y pruebas de usabilidad. Creamos interfaces accesibles, atractivas y orientadas al usuario para mejorar el rendimiento de tus productos digitales."
                      }
                    }
                  ]
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <HeaderSinglePage/>

      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="User Experience & User Interface" />
          
          <hr/>

          <section className="mt-4">
            <h2>¿Qué es UX/UI?</h2>

            <div className="faq">
              <p className="fs-5">
                El SEO (Search Engine Optimization) es un conjunto de técnicas que optimizan tu sitio web para mejorar su posicionamiento en los resultados de los motores de búsqueda como Google.
              </p>              

              <h3>¿Por qué es importante el diseño UX/UI?</h3>
              <p>
                Un buen diseño UX/UI mejora la satisfacción del usuario, facilita la navegación, reduce la tasa de rebote y aumenta las conversiones. Es clave para destacar frente a la competencia digital.
              </p>

              <h3>¿Qué servicios ofrece Dreamsign en UX/UI?</h3>
              <p>
                Ofrecemos investigación de usuarios, wireframing, prototipado y pruebas de usabilidad. Creamos interfaces accesibles, atractivas y orientadas al usuario para mejorar el rendimiento de tus productos digitales.
              </p>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ UxDesignWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ UxDesignJPG } 
                    width="100%"
                    height="100%" 
                    alt="User Experience"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Investigación de Usuarios:</h2>
                <p>
                  Analizamos el comportamiento y las necesidades de los usuarios, permitiéndonos crear diseños alineados con sus expectativas. Esto asegura que las interfaces estén optimizadas para el público objetivo y sus preferencias.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ WireframingWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ WireframingJPG } 
                    width="100%"
                    height="100%" 
                    alt="Wireframing y prototipado"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Wireframing y Prototipado</h2>
                <p>
                  Creamos esquemas y prototipos interactivos para definir la estructura y funcionalidad antes del desarrollo. Esto permite detectar mejoras y perfeccionar la interfaz, asegurando una experiencia de usuario excelente.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ UsabilityTestWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ UsabilityTestJPG } 
                    width="100%"
                    height="100%" 
                    alt="Pruebas de usabilidad"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Pruebas de Usabilidad:</h2>
                <p>
                  Evaluamos la eficacia del diseño realizando pruebas con usuarios reales, identificando posibles puntos de mejora. Este proceso garantiza una navegación sencilla y una experiencia positiva para todos los usuarios.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default UxUiPage
