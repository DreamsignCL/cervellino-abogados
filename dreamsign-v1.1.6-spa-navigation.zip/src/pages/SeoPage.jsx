import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';
import SeoJPG from '../assets/img/seo.jpg';
import SeoOffPageJPG from '../assets/img/seo-off-page.jpg';
import SeoTermsJPG from '../assets/img/seo-terms.jpg';
import SeoWEBP from '../assets/img/seo.webp';
import SeoOffPageWEBP from '../assets/img/seo-off-page.webp';
import SeoTermsWEBP from '../assets/img/seo-terms.webp';

function SeoPage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | Search Engine Optimization</title>
        <meta name="description" content="Conoce nuestro servicio de SEO que te permitirá mejorar la forma en que tus clientes te buscan en internet. Aumenta tu visibilidad y atrae tráfico orgánico de calidad." />
        <meta name="keywords" content="SEO, posicionamiento web, motores de búsqueda, link building, palabras clave, Dreamsign" />
        <link rel="canonical" href="https://dreamsign.cl/seo-marketing" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Service",
                  "name": "Search Engine Optimization",
                  "description": "Conoce nuestro servicio de SEO que te permitirá mejorar la forma en que tus clientes te buscan en internet. Aumenta tu visibilidad y atrae tráfico orgánico de calidad.",
                  "provider": {
                    "@type": "Organization",
                    "name": "Dreamsign",
                    "url": "https://www.dreamsign.cl",
                    "logo": {
                      "@type": "ImageObject",
                      "url": "https://www.dreamsign.cl/assets/logo.png",
                      "width": 500,
                      "height": 500
                    },
                    "sameAs": [
                      "https://www.facebook.com/DreamsignCL",
                      "https://x.com/DreamsignCL",
                      "https://www.instagram.com/dreamsigncl/",
                      "https://www.linkedin.com/company/dreamsigncl/"
                    ],
                    "contactPoint": {
                      "@type": "ContactPoint",
                      "telephone": "+56937351500",
                      "contactType": "customer service",
                      "areaServed": "CL",
                      "availableLanguage": "es"
                    }
                  },
                  "areaServed": {
                    "@type": "Country",
                    "name": "Chile"
                  },
                  "serviceType": "SEO On-Page, SEO Off-Page y análisis de palabras clave",
                  "url": "https://www.dreamsign.cl/seo-marketing",
                },
                {
                  "@type": "FAQPage",
                  "mainEntity": [
                    {
                      "@type": "Question",
                      "name": "¿Qué es el SEO?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "El SEO (Search Engine Optimization) es un conjunto de técnicas que optimizan tu sitio web para mejorar su posicionamiento en los resultados de los motores de búsqueda como Google."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Qué beneficios obtengo con SEO?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Con SEO aumentas tu visibilidad online, atraes más tráfico orgánico, mejoras la experiencia del usuario y generas más oportunidades de conversión."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Qué incluye el servicio SEO de Dreamsign?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Nuestro servicio incluye SEO On-Page (optimización de contenido y estructura), SEO Off-Page (link-building y autoridad), y análisis de palabras clave para maximizar tu alcance y posicionamiento."
                      }
                    }
                  ]
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <HeaderSinglePage/>

      <main role="main" className="single-page">
        <div className="container content-single-page">
          <MainHeader pageTitle="Seo en páginas web" />

          <hr/>

          <section className="mt-4">
            <h2>¿Qué es el SEO?</h2>

            <div className="faq">
              <p className="fs-5">
                El SEO (Search Engine Optimization) es un conjunto de técnicas que optimizan tu sitio web para mejorar su posicionamiento en los resultados de los motores de búsqueda como Google.
              </p>              

              <h3>¿Qué beneficios obtengo con SEO?</h3>
              <p>
                Con SEO aumentas tu visibilidad online, atraes más tráfico orgánico, mejoras la experiencia del usuario y generas más oportunidades de conversión.
              </p>

              <h3>¿Qué incluye el servicio SEO de Dreamsign?</h3>
              <p>
                Nuestro servicio incluye SEO On-Page (optimización de contenido y estructura), SEO Off-Page (link-building y autoridad), y análisis de palabras clave para maximizar tu alcance y posicionamiento.
              </p>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ SeoWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ SeoJPG } 
                    width="100%"
                    height="100%" 
                    alt="Search Engine Optimization"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">SEO On-Page</h2>
                <p>
                  Mejoramos el contenido y estructura de tu sitio, incluyendo títulos, etiquetas y velocidad de carga, para cumplir con las exigencias de los motores de búsqueda. Así, aseguramos una experiencia de usuario óptima y mejor ranking.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6">
                <picture>
                  <source srcSet={ SeoOffPageWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ SeoOffPageJPG } 
                    width="100%"
                    height="100%" 
                    alt="SEO Off Page"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">SEO Off-Page</h2>
                <p>
                  Implementamos estrategias de link-building y relaciones digitales para aumentar la autoridad de tu sitio. Estos enlaces de calidad ayudan a mejorar tu posicionamiento en buscadores, generando confianza y reputación.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ SeoTermsWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ SeoTermsJPG } 
                    width="100%"
                    height="100%" 
                    alt="SEO Terms"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Análisis de Palabras Clave</h2>
                <p>
                  Investigamos y seleccionamos las palabras clave más relevantes para tu audiencia, asegurando que tu sitio se enfoque en términos estratégicos que maximicen el tráfico de calidad y la conversión.
                </p>
                <p>
                  <a className="btn btn-outline-primary rounded-pill" aria-label="Cotizar servicio" href="#contact">Cotizar</a>
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default SeoPage
