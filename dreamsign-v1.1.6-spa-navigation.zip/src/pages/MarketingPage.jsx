import { Helmet } from 'react-helmet-async';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';

function MarketingPage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | Marketing para empresas</title>
        <meta name="description" content="Contrata con nosotros el plan de marketing que más te acomode. Contamos con diferentes formas y valores para hacer crecer tu empresa." />
        <meta name="keywords" content="Marketing digital, Estrategías, Análisis de datos, Posicionamiento" />
        <link rel="canonical" href="https://dreamsign.cl/marketing" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "name": "Planes de Marketing para Empresas",
              "description": "Ofrecemos planes que están diseñados para cubrir desde las necesidades más básicas hasta estrategias avanzadas de alto impacto.",
              "provider": {
                "@type": "Organization",
                "name": "Dreamsign",
                "url": "https://www.dreamsign.cl",
                "logo": {
                  "@type": "ImageObject",
                  "url": "https://www.dreamsign.cl/assets/logo.png",
                  "width": 500,
                  "height": 500
                },
                "sameAs": [
                  "https://www.facebook.com/DreamsignCL",
                  "https://x.com/DreamsignCL",
                  "https://www.instagram.com/dreamsigncl/",
                  "https://www.linkedin.com/company/dreamsigncl/"
                ],
                "contactPoint": {
                  "@type": "ContactPoint",
                  "telephone": "+56937351500",
                  "contactType": "customer service",
                  "areaServed": "CL",
                  "availableLanguage": "es"
                }
              },
              "areaServed": {
                "@type": "Country",
                "name": "Chile"
              },
              "serviceType": "Campañas corporativas, estrategías comerciales y marketing digital",
              "url": "https://www.dreamsign.cl/marketing"
            }
          `}
        </script>
      </Helmet>

      <HeaderSinglePage/>
      
      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="Planes de Marketing para Empresas" />
          
          <hr/>
          
          <p className="fs-5">
            En Dreamsign, entendemos que cada empresa tiene necesidades y objetivos únicos. Por eso, ofrecemos planes de marketing personalizados, diseñados para ayudarte a alcanzar el éxito en el mercado digital.
          </p>

          <p className="fs-5">
            Nuestros planes están diseñados para cubrir desde las necesidades más básicas hasta estrategias avanzadas de alto impacto. ¡Escoge el que mejor se adapte a tu negocio y comienza a destacar frente a tu competencia!
          </p>

          <section>
            <h2 className="subtitle">Cotiza tu plan mensual</h2>
            <p className="fs-4 my-5 text-center">
              ¡Por contrataciones desde los <strong>7 meses</strong>, te regalamos una <strong>página web básica</strong> para tu empresa!
            </p>

            <div className="row">
              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Esencial</h5>
                    <span>Perfecto para empresas que comienzan su viaje digital.</span>
                  </div>
                  <ul className="list-group list-group-flush">
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Asesoría de marketing
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> 8hrs. Cambios menores
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Posicionamiento SEO
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Google Analytics.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Hosting (20GB)
                      </li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>desde: 1.5UF <span className="fs-6">/mensual</span></h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>

              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Avanzado</h5>
                    <span>Ideal para negocios en pos de crecimiento.</span>
                  </div>
                  <ul className="list-group list-group-flush">
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Asesoría de marketing
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> 12hrs. Cambios menores
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Posicionamiento SEO
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Google Analytics.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Google Search Console.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Creación de RRSS.
                      </li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>desde: 2.5UF <span className="fs-6">/mensual</span></h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>

              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Premium</h5>
                    <span>Pensado para empresas que buscan alzar su impacto digital.</span>
                  </div>
                  <ul className="list-group list-group-flush">
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Asesoría de marketing
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> 16hrs. Cambios menores
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Posicionamiento SEO
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Google Analytics.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Google Search Console.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Creación de RRSS.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Administración de RRSS.
                      </li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>desde: 3.5UF <span className="fs-6">/mensual</span></h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>

              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Elite</h5>
                    <span>La solución completa para líderes del mercado.</span>
                  </div>
                  <ul className="list-group list-group-flush">
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Asesoría de marketing
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> 20hrs. Cambios menores
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Posicionamiento SEO
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Google Analytics.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Google Search Console.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Creación de RRSS.
                      </li>
                      <li className="list-group-item">
                          <FontAwesomeIcon className="text-primary" icon={faCheck} aria-hidden="true" /> Administración de RRSS.
                      </li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>desde: 4.5UF <span className="fs-6">/mensual</span></h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default MarketingPage
