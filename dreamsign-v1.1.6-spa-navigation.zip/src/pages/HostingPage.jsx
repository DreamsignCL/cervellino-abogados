import { Helmet } from 'react-helmet-async';
import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Footer from '../Footer';
import LogoDesignJPG from '../assets/img/hosting.jpg';
import LogoDesignWEBP from '../assets/img/hosting.webp';

function HostingPage() {
  return (
    <>
      <Helmet>
        <title>Dreamsign | Hosting</title>
        <meta name="description" content="Haloja tus sitios en las mismas dependencias de quien los diseña. ¡Contrata con nosotros! Contamos con un buen servicio de calidad para tus archivos." />
        <meta name="keywords" content="Hosting, arriendo de hosting, administración de dominios, servidores, alojamiento web" />
        <link rel="canonical" href="https://dreamsign.cl/hosting" />

        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@graph": [
                {
                  "@type": "Service",
                  "name": "Arriendo y Administración de Hosting",
                  "description": "Ofrecemos soluciones de hosting fiables y seguras para asegurar la presencia en línea de tu empresa. Con distintos planes y soporte constante, garantizamos un rendimiento óptimo, carga rápida y la seguridad necesaria para tu sitio.",
                  "provider": {
                    "@type": "Organization",
                    "name": "Dreamsign",
                    "url": "https://www.dreamsign.cl",
                    "logo": {
                      "@type": "ImageObject",
                      "url": "https://www.dreamsign.cl/assets/logo.png",
                      "width": 500,
                      "height": 500
                    },
                    "sameAs": [
                      "https://www.facebook.com/DreamsignCL",
                      "https://x.com/DreamsignCL",
                      "https://www.instagram.com/dreamsigncl/",
                      "https://www.linkedin.com/company/dreamsigncl/"
                    ],
                    "contactPoint": {
                      "@type": "ContactPoint",
                      "telephone": "+56937351500",
                      "contactType": "customer service",
                      "areaServed": "CL",
                      "availableLanguage": "es"
                    }
                  },
                  "areaServed": {
                    "@type": "Country",
                    "name": "Chile"
                  },
                  "serviceType": "Administración de dominios y arriendo de hosting",
                  "url": "https://www.dreamsign.cl/hosting",
                },
                {
                  "@type": "FAQPage",
                  "mainEntity": [
                    {
                      "@type": "Question",
                      "name": "¿Qué es hosting?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "El hosting es un servicio que permite alojar un sitio web en servidores para que esté accesible en Internet. Incluye almacenamiento, seguridad y soporte técnico."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Por qué elegir Dreamsign para hosting?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Ofrecemos hosting con soporte constante, altos estándares de seguridad, planes flexibles y administración completa de tu dominio, asegurando un rendimiento y uptime óptimos."
                      }
                    },
                    {
                      "@type": "Question",
                      "name": "¿Qué incluye el servicio de administración de dominios?",
                      "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Nos encargamos de la adquisición, renovación y protección de tu dominio para que siempre esté disponible y accesible, facilitando la gestión de tu presencia online."
                      }
                    }
                  ]
                }
              ]
            }
          `}
        </script>
      </Helmet>

      <HeaderSinglePage/>
      
      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="Arriendo y Administración de Hosting" />

          <hr/>

          <section className="mt-4">
            <h2>¿Qué es hosting?</h2>

            <div className="faq">
              <p className="fs-5">
                El hosting es un servicio que permite alojar un sitio web en servidores para que esté accesible en Internet. Incluye almacenamiento, seguridad y soporte técnico.
              </p>              

              <h3>¿Por qué elegir Dreamsign para hosting?</h3>
              <p>
                Ofrecemos hosting con soporte constante, altos estándares de seguridad, planes flexibles y administración completa de tu dominio, asegurando un rendimiento y uptime óptimos.
              </p>

              <h3>¿Qué incluye el servicio de administración de dominios?</h3>
              <p>
                Nos encargamos de la adquisición, renovación y protección de tu dominio para que siempre esté disponible y accesible, facilitando la gestión de tu presencia online.
              </p>
            </div>
          </section>

          <section>
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <picture>
                  <source srcSet={ LogoDesignWEBP } type="image/webp"  />
                  <img 
                    className="img-fluid rounded" 
                    src={ LogoDesignJPG } 
                    width="100%"
                    height="100%" 
                    alt="Administración de hosting"
                    loading="lazy" />
                </picture>
              </div>
              <div className="col-12 col-md-6 order-md-first">
                <h2 className="subtitle">Administración de dominios</h2>
                <p>
                  Gestionamos la adquisición, renovación y protección de tu dominio, asegurando que tu marca siempre esté disponible y accesible en línea. Nos encargamos de toda la administración para tu tranquilidad.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="subtitle mb-5">Cotiza tu plan</h2>
            <div className="row">
              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Plan Básico</h5>
                    <span>Para comenzar una web</span>
                  </div>
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">Ilimitado Espacio Web</li>
                    <li className="list-group-item">100GB Transferencia Mensual</li>
                    <li className="list-group-item">Ilimitadas Cuentas de Email</li>
                    <li className="list-group-item">Certificado SSL ¡GRATIS!</li>
                    <li className="list-group-item">Transferencia: Ilimitada</li>
                    <li className="list-group-item">Ilimitadas BD MySQL</li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>$10.000</h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>

              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Plan Medio</h5>
                    <span>Para comenzar una web</span>
                  </div>
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">30GB de espacio SSD</li>
                    <li className="list-group-item">50 Cuentas de Email</li>
                    <li className="list-group-item">Certificado SSL ¡GRATIS!</li>
                    <li className="list-group-item">Transferencia: Ilimitada</li>
                    <li className="list-group-item">5 Bases de Datos</li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>$16.000</h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>

              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Plan Alto</h5>
                    <span>Para comenzar una web</span>
                  </div>
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">40GB de espacio SSD</li>
                    <li className="list-group-item">Cuentas de Email Ilimitadas</li>
                    <li className="list-group-item">Certificado SSL ¡GRATIS!</li>
                    <li className="list-group-item">Transferencia: Ilimitada</li>
                    <li className="list-group-item">20 Bases de Datos</li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>$24.000</h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>

              <div className="col-12 col-md-3">
                <div className="card">
                  <div className="card-header text-center">
                    <h5 className="card-title">Plan Premium</h5>
                    <span>Para comenzar una web</span>
                  </div>
                  <ul className="list-group list-group-flush">
                    <li className="list-group-item">120GB de espacio SSD</li>
                    <li className="list-group-item">Cuentas de Email Ilimitadas</li>
                    <li className="list-group-item">Certificado SSL ¡GRATIS!</li>
                    <li className="list-group-item">Transferencia: Ilimitada</li>
                    <li className="list-group-item">Bases de Datos Ilimitadas</li>
                  </ul>
                  <div className="card-footer text-center">
                    <h4>$34.000</h4>
                    <a className="btn btn-outline-primary rounded-pill" href="#contact">Solicitar</a>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default HostingPage
