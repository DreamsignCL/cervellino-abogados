import HeaderSinglePage from '../HeaderSinglePage';
import MainHeader from '../assets/components/MainHeader';
import Services from '../assets/components/Services';
import Footer from '../Footer';

function NotFound() {
  return (
    <>
      <HeaderSinglePage/>
      <main role="main" className="single-page">
        <div className="container">
          <MainHeader pageTitle="404 - Página no encontrada" />
          <p className="fs-5">
            Lo sentimos, la página que buscas no se encuentra en nuestros registros.
          </p>

          <hr/>

          <section>
            <h2>Tal vez te pueda interesar alguno de nuestros servicios</h2>
            <Services />
          </section>
        </div>
      </main>
      <Footer/>
    </>
  );
}

export default NotFound