import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { trackCtaClick } from '../utils/analytics';
import Header from '../Header';
import Footer from '../Footer';
import useBlogPosts from '../hooks/useBlogPosts';
import BlogList from '../assets/components/BlogList';
import Clients from '../assets/components/Clients';
import Services from '../assets/components/Services';
import CodingVideo from '../assets/img/coding.mp4';
import LaptopCodingJPG from '../assets/img/coding.jpg';
import SketchBookImageJPG from '../assets/img/drawing.jpg';
import LaptopMaskPNG from '../assets/img/laptop.png';
import LaptopCodingWEBP from '../assets/img/coding.webp';
import SketchBookImageWEBP from '../assets/img/drawing.webp';
import LaptopMaskWEBP  from '../assets/img/laptop.webp';
import LogoDsRest  from '../assets/img/logo-dsrest.svg';
import DsRestBackgroundAnimation  from '../assets/components/DsRestBackgroundAnimation';
import Model3DHome from "../assets/components/Model3DHome";


function HomePage() {
  const { posts, loading } = useBlogPosts();

  return (
    <>
      <Helmet>
        <title>Dreamsign | Software a medida e I+D</title>
        <meta name="description" content="Desarrollamos software a medida, webapps y soluciones digitales para empresas que necesitan resolver problemas reales de negocio." />
        <meta name="keywords" content="software a medida, desarrollo de software, webapps, software factory, I+D, automatización" />
        <link rel="canonical" href="https://dreamsign.cl" />

        <meta property="og:title" content="Dreamsign | Software a medida e I+D" />
        <meta property="og:description" content="Software a medida e I+D para convertir problemas de negocio en soluciones digitales." />
        <meta property="og:image" content="https://dreamsign.cl/assets/og-facebook.jpg" />
        <meta property="og:url" content="https://dreamsign.cl" />
        <meta property="og:type" content="website" />
        <meta property="og:locale" content="es_CL" />
        <meta property="og:site_name" content="Dreamsign" />
        <meta property="article:publisher" content="https://www.facebook.com/DreamsignCL" />

        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Dreamsign | Software a medida e I+D" />
        <meta name="twitter:description" content="Desarrollo de software a medida y soluciones digitales para empresas." />
        <meta name="twitter:image" content="https://dreamsign.cl/assets/og-facebook.jpg" />

        <script type="application/ld+json">
          {`
            {
            "@context": "http://schema.org",
            "@type": "Organization",
            "name": "Dreamsign",
            "url": "https://dreamsign.cl",
            "logo": {
              "@type": "ImageObject",
              "url": "https://dreamsign.cl/assets/logo.png",
              "width": 500,
              "height": 500,
              "contentUrl": "https://dreamsign.cl/assets/logo.svg"
            },
            "areaServed": {
              "@type": "Country",
              "name": "Chile"
            },
            "sameAs": [
              "https://www.facebook.com/DreamsignCL",
              "https://x.com/DreamsignCL",
              "https://www.instagram.com/dreamsigncl/",
              "https://www.linkedin.com/company/dreamsigncl/"
            ],
            "contactPoint": {
              "@type": "ContactPoint",
              "telephone": "+56937351500",
              "contactType": "customer service",
              "areaServed": "CL",
              "availableLanguage": "Spanish"
            }
          }
          `}
        </script>
      </Helmet>

      <Header/>
      
      <main role="main" className="home-page">
        <section className="header">
          <div className="container">
            <div className="row">
              <div className="col-12 col-md-6">
                <h1 className="text-white">Convertimos problemas de negocio en software.</h1>
                <h2 className="text-white">Desarrollo a medida e I+D para empresas.</h2>
                <p>
                  Diseñamos y construimos sistemas, webapps y soluciones digitales a medida cuando las herramientas existentes no son suficientes.
                </p>
                <a className="btn btn-light rounded-pill btn-lg" href="#contact" aria-label="Cuéntanos tu proyecto" onClick={() => trackCtaClick({ ctaName: "cuentanos_tu_proyecto", destination: "#contact", location: "home_hero" })}>Cuéntanos tu proyecto</a>
              </div>
              <div className="col-12 col-md-6 d-none d-md-flex">
                <figure className="figure">
                  <picture>
                    <source srcSet={ LaptopCodingWEBP } type="image/webp" />
                    <img 
                      className="figure-img img-fluid rounded" 
                      src={ LaptopCodingJPG }
                      width="100%"
                      height="100%" 
                      alt="Laptop mostrando código en pantalla" />
                  </picture>
                </figure>

                <figure className="figure">
                  <picture>
                    <source srcSet={ SketchBookImageWEBP } type="image/webp" />
                    <img 
                      className="figure-img img-fluid rounded" 
                      src={ SketchBookImageJPG }
                      width="100%"
                      height="100%" 
                      alt="Sketchbook abierto con bocetos de diseño digital" />
                  </picture>
                </figure>
              </div>
            </div>
          </div>
          <div className="mask-top"></div>
        </section>

        <section id="blog" className="blog">
          <div className="container">
            <h2 className="subtitle mb-5">Últimas noticias</h2>
            {loading ? <p>Cargando...</p> : (
              <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
                <BlogList posts={posts} limit={4} />
              </div>
            )}
          </div>
          <div className="text-center">
            <Link className="btn btn-primary rounded-pill btn-lg " to="/blog" onClick={() => trackCtaClick({ ctaName: "ver_todos_blog", destination: "/blog", location: "home_blog" })}>Ver todos</Link>
          </div>
        </section>

        <section id="services" className="services">
          <div className="container">
            <h2 className="subtitle mb-5">Nuestros Servicios</h2>
            <Services />
          </div>
        </section>

        <section id="dsRest" className="dsRest">
          <DsRestBackgroundAnimation />
          <div className="container">
            <div className="row">
              <div className="col-12 col-md-6 order-md-last">
                <div className="model3D">
                  <Model3DHome />
                </div>
              </div>
              <div className="col-12 col-md-6">
                <div className="content">
                  <h2>Conoce nuestro nuevo servicio dsRest</h2>
                  <p>La aplicación que renovará la forma en que muestras tu restaurant</p>
                  <img src={LogoDsRest} width="100%" height="100%" alt="Logotipo de dsRest"></img>
                  <Link className="btn btn-warning rounded-pill btn-lg " to="/dsrest" onClick={() => trackCtaClick({ ctaName: "conoce_dsrest", destination: "/dsrest", location: "home_dsrest" })}>Conoce más</Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="about_us" className="about-us">
          <div className="container">
            <div className="row">
              <div className="col-12 col-md-6">
                <div className="coding-animation">
                  <div className="laptop-container" width="100%" height="100%">
                    <picture>
                      <source srcSet={ LaptopMaskWEBP } type="image/webp" />
                      <img src={ LaptopMaskPNG } alt="" />
                    </picture>
                  </div>
                  <div className="video-container">
                    <video className="video video-coding" playsInline autoPlay={"autoplay"} muted loop>
                      <source src={ CodingVideo } type="video/mp4" />
                      Tu navegador no es compatible con este formato de video.
                    </video>
                  </div>
                </div>
              </div>
              <div className="col-12 col-md-6">
                <h2 className="subtitle">Acerca de nosotros</h2>
                <p>
                  Somos una empresa especializada en soluciones digitales integrales. Nos enfocamos en:
                </p>
                <p>
                  Marketing y desarrollo de plataformas digitales para potenciar la presencia online de nuestros clientes. Contamos con diseño corporativo y desarrollo de software a medida.
                </p>

                <p>
                  Nuestro compromiso es entregar productos de alta calidad, respaldados por procesos basados en estándares internacionales en la construcción de software.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="promo-section">
          <div className="mask">
            <div className="content">
              ¿Quieres darle una mejora comunicacional a tu empresa?<br></br>
              <span>Elige el plan de marketing que más se acomode a tu empresa</span>
              <p className="mt-2">
                <a 
                  className="btn btn-primary rounded-pill" 
                  href="/marketing" 
                  title="Conoce nuestros planes de marketing"
                  aria-label="Ver detalles de los planes de marketing"
                  onClick={() => trackCtaClick({ ctaName: "planes_marketing", destination: "/marketing", location: "home_promo" })}>
                    CONOCE NUESTROS PLANES
                </a>
              </p>
            </div>
          </div>
        </section>

        <section id="clients" className="clients">
          <div className="container">
            <h2 className="mb-5 text-center text-primary">Han confiado en nosotros</h2>
            <Clients />
          </div>
        </section>
      </main>
      <Footer/>
    </>
  );
}

export default HomePage
