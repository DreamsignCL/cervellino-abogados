import React, { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import RoutesMap from "./RoutesMap";
import { pushAnalyticsEvent, trackPageView } from "./utils/analytics";

function App() {
  const location = useLocation();
  const lastTrackedRoute = useRef(null);
  const pendingPageViewRoute = useRef(null);
  const lastPageViewRoute = useRef(null);

  useEffect(() => {
    const routeKey = `${location.pathname}${location.search}`;
    const pagePath = location.pathname;

    if (lastTrackedRoute.current === routeKey) return;
    lastTrackedRoute.current = routeKey;

    // react-helmet-async actualiza document.title después del render. En
    // desarrollo, React StrictMode puede ejecutar este efecto dos veces; por
    // eso programamos el page_view solo una vez por ruta y dejamos que el
    // chequeo espere hasta que el título esté realmente disponible.
    if (pendingPageViewRoute.current !== routeKey) {
      pendingPageViewRoute.current = routeKey;

      let attempts = 0;
      const waitForTitleAndTrack = () => {
        if (
          pendingPageViewRoute.current !== routeKey ||
          lastPageViewRoute.current === routeKey
        ) {
          return;
        }

        const title = document.title.trim();

        if (title || attempts >= 60) {
          lastPageViewRoute.current = routeKey;
          trackPageView({
            path: pagePath,
            title,
          });
          return;
        }

        attempts += 1;
        requestAnimationFrame(waitForTitleAndTrack);
      };

      requestAnimationFrame(waitForTitleAndTrack);
    }

    const serviceRoutes = {
      '/design': 'Diseño corporativo',
      '/web-development': 'Desarrollo web',
      '/hosting': 'Hosting',
      '/seo-marketing': 'SEO / SEM',
      '/user-experience': 'Diseño UX / UI',
      '/quality-assurance': 'Servicio QA',
      '/accessibility': 'Accesibilidad web',
    };

    if (serviceRoutes[location.pathname]) {
      pushAnalyticsEvent('service_view', {
        service_name: serviceRoutes[location.pathname],
        page_path: pagePath,
      });
    }

    if (location.pathname === '/dsrest') {
      pushAnalyticsEvent('product_view', {
        product_name: 'dsRest',
        page_path: pagePath,
      });
    }

  }, [location.pathname, location.search]);

  return <RoutesMap />;
}

export default App;
