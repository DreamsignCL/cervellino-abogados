import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';

const HomePage = lazy(() => import('./pages/HomePage'));
const DesignPage = lazy(() => import('./pages/DesignPage'));
const WebDevelopePage = lazy(() => import('./pages/WebDevelopePage'));
const HostingPage = lazy(() => import('./pages/HostingPage'));
const SeoPage = lazy(() => import('./pages/SeoPage'));
const UxUiPage = lazy(() => import('./pages/UxUiPage'));
const QaPage = lazy(() => import('./pages/QAPage'));
const AccessibilityPage = lazy(() => import('./pages/AccessibilityPage'));
const MarketingPage = lazy(() => import('./pages/MarketingPage'));
const Webinar = lazy(() => import('./pages/Webinar'));
const DsRest = lazy(() => import('./pages/DsRestPage'));
const NotFound = lazy(() => import('./pages/NotFound'));

// 👉 Nuevos componentes del blog
const BlogPage = lazy(() => import('./pages/BlogPage'));
const BlogPost = lazy(() => import('./assets/components/BlogPost'));

function RoutesMap() {
  return (
    <Suspense fallback={<div aria-busy="true">Cargando...</div>}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/design" element={<DesignPage />} />
        <Route path="/web-development" element={<WebDevelopePage />} />
        <Route path="/hosting" element={<HostingPage />} />
        <Route path="/seo-marketing" element={<SeoPage />} />
        <Route path="/user-experience" element={<UxUiPage />} />
        <Route path="/quality-assurance" element={<QaPage />} />
        <Route path="/accessibility" element={<AccessibilityPage />} />
        <Route path="/marketing" element={<MarketingPage />} />
        <Route path="/webinars" element={<Webinar />} />
        <Route path="/dsrest" element={<DsRest />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/blog/:slug" element={<BlogPost />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}

export default RoutesMap;
