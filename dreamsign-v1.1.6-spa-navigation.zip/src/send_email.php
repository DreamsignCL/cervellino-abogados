<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

header("Access-Control-Allow-Origin: https://www.dreamsign.cl");
header("Vary: Origin");
header("Content-Type: application/json; charset=UTF-8");

// Clave secreta reCAPTCHA v2 (esta la obtienes desde Google)
$recaptchaSecret = '6LfRQi8rAAAAAMgBUc36swe6rdVrGAbuAe-0YdhK'; // <-- Reemplaza con tu clave secreta

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar reCAPTCHA
    $captchaToken = $_POST['g-recaptcha-response'] ?? '';

    if (empty($captchaToken)) {
        echo json_encode(["status" => "error", "message" => "Falta el token de reCAPTCHA"]);
        exit;
    }

    // Verificación con Google
    $recaptchaResponse = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=" . $recaptchaSecret . "&response=" . $captchaToken);
    $recaptchaData = json_decode($recaptchaResponse);

    if (!$recaptchaData->success) {
        echo json_encode([
            "status" => "error",
            "message" => "Verificación reCAPTCHA fallida",
            "recaptcha_debug" => $recaptchaData
        ]);
        exit;
    }

    // Recibir los datos del formulario
    $nombre = $_POST['Nombre'] ?? '';
    $email = $_POST['Email'] ?? '';
    $asunto = $_POST['Asunto'] ?? '';
    $comentario = $_POST['Comentario'] ?? '';

    $mail = new PHPMailer(true);

    try {
        // Configuración del servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'mail.dreamsign.cl';
        $mail->SMTPAuth = true;
        $mail->Username = 'no-responder@dreamsign.cl';
        $mail->Password = 'DSAgencia2020';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        // Configuración del email
        $mail->setFrom($email, $nombre);
        $mail->addAddress('cotizaciones@dreamsign.cl');
        $mail->isHTML(true);
        $mail->Subject = "Nuevo contacto desde la web - " . $asunto;
        $mail->Body = "<p><strong>Nombre:</strong> $nombre</p>
                       <p><strong>Email:</strong> $email</p>
                       <p><strong>Asunto:</strong> $asunto</p>
                       <p><strong>Comentario:</strong><br>$comentario</p>";

        $mail->send();
        echo json_encode(["status" => "success", "message" => "Correo enviado exitosamente"]);
    } catch (Exception $e) {
        echo json_encode([
            "status" => "error",
            "message" => "No se pudo enviar el correo",
            "error" => $mail->ErrorInfo
        ]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método no permitido"]);
}
?>