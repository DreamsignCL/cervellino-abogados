import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';

function MainHeader(props){
    return(
        <header>
            <h1>{ props.pageTitle }</h1>
            <a
                className="btn btn-outline-primary rounded-pill"
                aria-label="Volver al inicio"
                href="/">
                <FontAwesomeIcon icon={faChevronLeft} aria-hidden="true" />
                Volver
            </a>
        </header>
    );
}

export default MainHeader