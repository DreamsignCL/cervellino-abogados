import React, { Suspense, useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Environment, useGLTF, Html } from "@react-three/drei";

function Modelo({ path }) {
  const gltf = useGLTF(path);

  useEffect(() => {
    if (import.meta.env.DEV && gltf?.scene) {
      console.log("✅ Modelo cargado correctamente:", gltf);
    }
  }, [gltf, path]);

  return gltf?.scene ? (
    //<primitive object={gltf.scene} position={[0, -1.3, 0]} scale={0.6} rotation={[0, Math.PI, 0]} />
    <primitive object={gltf.scene} position={[0, 0, 0]} scale={0.35} rotation={[-0.1, -0.4, -0.2]} />
  ) : null;
}

export default function Model3DHome() {
  const modelPath = "/models/dsrest3D.glb";

  return (
    <Canvas
      style={{ height: "450px", background: "transparent" }}
      camera={{ position: [0, 0, 1.9] }}
      frameloop="demand"
      gl={{ alpha: true, preserveDrawingBuffer: true }}
    >
      <ambientLight intensity={1} />
      <Suspense fallback={<Html center><p>Cargando modelo...</p></Html>}>
        <Modelo path={modelPath} />
        <Environment files="/models/venice_sunset_1k.hdr" />
      </Suspense>
      <OrbitControls enableZoom={false} />
    </Canvas>
  );
}