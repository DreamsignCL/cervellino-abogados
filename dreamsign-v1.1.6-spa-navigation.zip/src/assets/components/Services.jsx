import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenNib, faCode, faServer, faChartLine, faObjectUngroup, faUniversalAccess, faMedal } from '@fortawesome/free-solid-svg-icons';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import CardService from './CardService';

function services(){
    const servicesList = [
        {
            id:1,
            name: 'Diseño corporativo',
            content: 'Comienza o mejora la imagen de tu empresa con los mejores estándares.',
            bgColor: 'bg-info',
            icon: <FontAwesomeIcon icon={faPenNib} aria-hidden="true" size="3x" />,
            link: 'design'
        },
        {
            id:2,
            name: 'Desarrollo web',
            content: 'Forma parte de internet con nuestro desarrollo web que se ajuste a tu medida.',
            bgColor: 'bg-success',
            icon: <FontAwesomeIcon icon={faCode} aria-hidden="true" size="3x" />,
            link: 'web-development'
        },
        {
            id:3,
            name: 'Hosting',
            content: 'Mejora la calidad y velocidad de tu servicio web con nuestros planes de Hosting.',
            bgColor: 'bg-warning',
            icon: <FontAwesomeIcon icon={faServer} aria-hidden="true" size="3x" />,
            link: 'hosting'
        },
        {
            id:4,
            name: 'SEO / SEM',
            content: 'Haz que tu página llegue a más personas mejorando su posicionamiento.',
            bgColor: 'bg-dark-subtle',
            icon: <FontAwesomeIcon icon={faChartLine} aria-hidden="true" size="3x" />,
            link: 'seo-marketing'
        },
        {
            id:4,
            name: 'Diseño UX / UI',
            content: 'Mejora el acceso de público a tu sitio web con nuestro servicio de UX/UI.',
            bgColor: 'bg-dark',
            icon: <FontAwesomeIcon icon={faObjectUngroup} aria-hidden="true" size="3x" />,
            link: 'user-experience'
        },
        {
            id:5,
            name: 'Servicio QA',
            content: 'Experiencia, Buenas Prácticas ISTQB, y Enfoque en Accesibilidad y UX/UI.',
            bgColor: 'bg-primary',
            icon: <FontAwesomeIcon icon={faMedal} aria-hidden="true" size="3x" />,
            link: 'quality-assurance'
        },
        {
            id:6,
            name: 'Accesibilidad web',
            content: 'Deja que todo tu publico disfrute de tu negocio mejorando el acceso a el.',
            bgColor: 'bg-danger',
            icon: <FontAwesomeIcon icon={faUniversalAccess} aria-hidden="true" size="3x" />,
            link: 'accessibility'
        },
    ];

    const sliderItems = servicesList.map(serviceItem => 
        <CardService
            serviceIcon= { serviceItem.icon }
            serviceBgColor= { serviceItem.bgColor }
            serviceName= { serviceItem.name } 
            serviceContent= { serviceItem.content }
            serviceLink= { serviceItem.link }
            key= {serviceItem.id}
        />
    );

    var settings = {
        dots: true,
        infinite: false,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 3,
        responsive: [
            {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
            }
        ]
    };

    return(
        <>
            <Slider {...settings}>
                { sliderItems }
            </Slider>
        </>
    );
}

export default services