function InputField(props){
    return(
        <div className="mb-3">
            <input 
                type={props.type}
                className="form-control"  
                placeholder={props.placeholder}
                aria-label={props.ariaLabel}
                >
            </input>
        </div>
    );
}

export default InputField