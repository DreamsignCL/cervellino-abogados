import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import bgWebinar from '../img/bg-webinar.avif';

function ModalHome() {
    const [showModal, setShowModal] = useState(false);

    const handleShow = () => setShowModal(true);

    const handleClose = () => setShowModal(false);

    // Referencia al body para devolver el foco al cerrar el modal
    const bodyRef = React.useRef(null);

    useEffect(() => {
        handleShow();

        // Guardar la posición del foco cuando se abre el modal
        const previousActiveElement = document.activeElement;
        // Darle focus al body para evitar el error mencionado
        bodyRef.current?.setAttribute('inert', true);

        return () => {
            // Quitar el inert cuando se cierra el modal
            bodyRef.current?.removeAttribute('inert');
            previousActiveElement?.focus();
        };
    }, []);

    return (
        <>
            <div
                className={`modal fade ${showModal ? 'show' : ''}`}
                tabIndex="-1"
                role="dialog"
                aria-hidden={!showModal}
                style={{ display: showModal ? 'block' : 'none' }}
                onClick={handleClose}
                aria-labelledby="modalLabel">
                <div
                    className="modal-dialog modal-dialog-promo modal-dialog-centered"
                    role="document"
                    onClick={(e) => e.stopPropagation()}>
                    <div
                        className="modal-content"
                        style={{ backgroundImage: `url(${bgWebinar})` }}>
                        <div className="modal-header bg-dark">
                            <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                                onClick={handleClose}></button>
                        </div>
                        <div className="modal-body text-white text-center" style={{ backgroundColor: 'rgba(0,0,0,.3)' }}>
                            <span className="fs-6">Te invitamos a nuestro webinar</span>
                            <span id="modalLabel" className="h3 text-white">El ABC del Marketing Digital</span>

                            <hr/>

                            <p className="fs-4">
                                Hablaremos sobre la importancia de la <strong>Web</strong>, las <strong>Redes Sociales</strong> y el <strong>Posicionamiento</strong> para tu negocio
                            </p>
                            <p className="fs-5">
                                Será el día 12 de Abril a las 11:00am vía online.<br></br>
                                <strong>¡Y es totalmente gratis!</strong>
                            </p>
                        </div>
                        <div className="modal-footer justify-content-center bg-dark">
                            <Link className="btn btn-primary rounded-pill" to="/webinars">
                                ¡Inscribete Ahora!
                            </Link>
                        </div>
                    </div>
                </div>
            </div>

            {/* Fondo con baja opacidad, la capa de backdrop */}
            {showModal && <div className="modal-backdrop fade show" onClick={handleClose}></div>}
        </>
    );
}

export default ModalHome;
