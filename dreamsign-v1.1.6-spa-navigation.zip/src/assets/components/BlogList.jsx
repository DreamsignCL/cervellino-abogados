import BlogCard from './BlogCard';

export default function BlogList({ posts, limit }) {
  const limitedPosts = limit ? posts.slice(0, limit) : posts;

  return (
    <>
      {limitedPosts.map(post => (
        <div key={post.slug} className="col">
          <BlogCard post={post} />
        </div>
      ))}
    </>
  );
}