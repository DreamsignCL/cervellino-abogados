import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import FavorConcedidoSVG from '../img/favor-concedido.svg';
import PabloIzquierdoPNG from '../img/pablo-izquierdo.png';
import ConstructoraGlassPNG from '../img/constructora-glass.png';
import AdemaroPellacaniPNG from '../img/pellacani.png';
import MicroChilePNG from '../img/microchile.png';
import TaibaLegal from '../img/taibalegal.svg';
import PabloIzquierdoWEBP from '../img/pablo-izquierdo.webp';
import ConstructoraGlassWEBP from '../img/constructora-glass.webp';
import AdemaroPellacaniWEBP from '../img/pellacani.webp';
import MicroChileWEBP from '../img/microchile.webp';


function clients(){
    const clientsList = [
        {
            id:1,
            name: 'Favor Concedido',
            logo: FavorConcedidoSVG,
            logo2: FavorConcedidoSVG,
            class: 'favor-concedido',
            link: 'https://www.favorconcedido.cl/'
        },
        {
            id:2,
            name: 'Pablo Izquierdo Echeverria',
            logo: PabloIzquierdoPNG,
            logo2: PabloIzquierdoWEBP,
            class: 'pablo-izquierdo',
            link: 'https://www.pabloizquierdo.cl/'
        },
        {
            id:3,
            name: 'Constructora Glass',
            logo: ConstructoraGlassPNG,
            logo2: ConstructoraGlassWEBP,
            class: 'constructora-glass',
            link: 'https://www.constructoraglass.cl/'
        },
        {
            id:4,
            name: 'Ademaro Pellacani',
            logo: AdemaroPellacaniPNG,
            logo2: AdemaroPellacaniWEBP,
            class: 'ademaro-pellacani',
            link: 'https://www.pellacani.cl/'
        },
        {
            id:5,
            name: 'Micro Chile',
            logo: MicroChilePNG,
            logo2: MicroChileWEBP,
            class: 'microchile',
            link: 'https://www.microchile.cl/'
        },
        {
            id:6,
            name: 'Taiba Legal',
            logo: TaibaLegal,
            logo2: TaibaLegal,
            class: 'taibalegal',
            link: 'https://www.taibalegal.cl/'
        },
    ];

    const sliderItems = clientsList.map(clientItem => 
        <div className="slider-client-item" key={clientItem.id}>
            <figure className={'client ' + clientItem.class}>
                <a href={clientItem.link} target="_blank" aria-label={`Ir al sitio web de ${clientItem.name}`} title={`Visitar el sitio web de ${clientItem.name}`}>
                    <picture>
                        <source srcSet={ clientItem.logo2 } type="image/webp"  />
                        <img 
                            className="img-fluid rounded" 
                            src={ clientItem.logo }
                            width="100%"
                            height="100%" 
                            alt={`Logo de ${clientItem.name}`}/>
                    </picture>
                </a>
                <figcaption>{clientItem.name}</figcaption>
            </figure>
        </div>
    );

    const settings = {
        dots: true,
        infinite: true,
        speed: 2000,
        autoplay: true,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplaySpeed: 2000,
        cssEase: "linear",
        arrows: false,
        responsive: [
            {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
            }
        ]
    };

    return(
        <>
            <Slider className="slider-clients" {...settings}>
                { sliderItems }
            </Slider>
        </>
    );
}

export default clients