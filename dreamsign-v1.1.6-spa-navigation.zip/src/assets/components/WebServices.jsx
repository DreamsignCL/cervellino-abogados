import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import CardService2 from './CardService2';
import WebServiceImage from '../img/price1.svg';
import WebServiceImage2 from '../img/price2.svg';
import WebServiceImage3 from '../img/price3.svg';
import WebServiceImage4 from '../img/price4.svg';

function services(){
    const servicesList = [
        {
            id:1,
            name: 'Web Básica',
            content: 'Para comenzar la aventura de tener tu sitio web. Esta es tu mejor opción',
            image: WebServiceImage
        },
        {
            id:2,
            name: 'Web Admin',
            content: '¿Necesitas manejar tu mismo los contenidos de tu sitio? ¡Esta opción es para ti!',
            image: WebServiceImage2
        },
        {
            id:3,
            name: 'E-Commerce',
            content: '¿Necesitas vender tus productos o servicios? ¡Crea tu tienda ahora mismo!',
            image: WebServiceImage3
        },
        {
            id:4,
            name: 'Web APP',
            content: '¿Tienes una idea de sistema y no sabes como hacerlo? ¡Consulta con nosotros!',
            image: WebServiceImage4
        },
    ];

    const sliderItems = servicesList.map(serviceItem => 
        <CardService2
            serviceImage= { serviceItem.image }
            serviceName= { serviceItem.name } 
            serviceContent= { serviceItem.content } 
            key= {serviceItem.id}
        />
    );

    var settings = {
        dots: true,
        infinite: false,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 3,
        responsive: [
            {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
            }
        ]
    };

    return(
        <>
            <Slider {...settings}>
                { sliderItems }
            </Slider>
        </>
    );
}

export default services