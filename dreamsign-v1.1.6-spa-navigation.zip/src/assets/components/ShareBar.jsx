import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faFacebook, faXTwitter, faWhatsapp, faLinkedin
} from '@fortawesome/free-brands-svg-icons';
import { faClipboard } from '@fortawesome/free-solid-svg-icons';
import { pushAnalyticsEvent } from '../../utils/analytics';

export default function ShareBar({ title }) {
  const url = window.location.href;
  const encodedTitle = encodeURIComponent(title);
  const encodedUrl = encodeURIComponent(url);

  const shareLinks = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    whatsapp: `https://api.whatsapp.com/send?text=${encodedTitle}%20${encodedUrl}`
  };

  const trackShare = (platform) => {
    pushAnalyticsEvent('blog_share', {
      platform,
      content_type: 'blog',
      content_title: title,
    });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(url).then(() => {
      pushAnalyticsEvent('blog_share', {
        platform: 'copy_link',
        content_type: 'blog',
        content_title: title,
      });
      alert('Enlace copiado al portapapeles ✅');
    });
  };

  return (
    <div className="sharebar d-flex align-items-center gap-2">
      <span className="text-muted me-2">Compartir:</span>

      <a className="btn-facebook" href={shareLinks.facebook} target="_blank" rel="noopener noreferrer" data-bs-toggle="tooltip" data-bs-title="Compartir en Facebook" onClick={() => trackShare('facebook')}>
        <FontAwesomeIcon icon={faFacebook} />
      </a>

      <a className="btn-x" href={shareLinks.twitter} target="_blank" rel="noopener noreferrer" data-bs-toggle="tooltip" data-bs-title="Compartir en X" onClick={() => trackShare('x')}>
        <FontAwesomeIcon icon={faXTwitter} />
      </a>

      <a className="btn-linkedin" href={shareLinks.linkedin} target="_blank" rel="noopener noreferrer" data-bs-toggle="tooltip" data-bs-title="Compartir en LinkedIn" onClick={() => trackShare('linkedin')}>
        <FontAwesomeIcon icon={faLinkedin} />
      </a>

      <a className="btn-whatsapp" href={shareLinks.whatsapp} target="_blank" rel="noopener noreferrer" data-bs-toggle="tooltip" data-bs-title="Compartir en WhatsApp" onClick={() => trackShare('whatsapp')}>
        <FontAwesomeIcon icon={faWhatsapp} />
      </a>

      <button className="btn-copy" onClick={handleCopy} data-bs-toggle="tooltip" data-bs-title="Copiar enlace" type="button">
        <FontAwesomeIcon icon={faClipboard} />
      </button>
    </div>
  );
}
