import { useParams } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import rehypeRaw from 'rehype-raw';
import fm from 'front-matter';
import { Helmet } from 'react-helmet-async';
import { useEffect, useRef, useState } from 'react';
import HeaderSinglePage from '../../HeaderSinglePage';
import ShareBar from '../components/ShareBar';
import SidebarRelatedPosts from '../components/SidebarRelatedPosts';
import Footer from '../../Footer';
import Tooltip from 'bootstrap/js/dist/tooltip';
import { pushAnalyticsEvent } from '../../utils/analytics';

export default function BlogPost() {
  const { slug } = useParams();
  const [attributes, setAttributes] = useState({});
  const [body, setBody] = useState('');
  const [error, setError] = useState(false);
  const trackedSlugRef = useRef(null);

  useEffect(() => {
    const tooltipTriggerList = Array.from(
      document.querySelectorAll('[data-bs-toggle="tooltip"]')
    );
    tooltipTriggerList.forEach(el => {
      new Tooltip(el);
    });

    fetch(`/blog/${slug}.md`)
      .then((res) => {
        if (!res.ok) throw new Error('Post no encontrado');
        return res.text();
      })
      .then((text) => {
        const { attributes, body } = fm(text);
        setAttributes(attributes);
        setBody(body);

        if (trackedSlugRef.current !== slug) {
          trackedSlugRef.current = slug;
          pushAnalyticsEvent("blog_view", {
            content_type: "blog",
            content_slug: slug,
            content_title: attributes.title,
            content_categories: attributes.categories || [],
          });
        }
      })
      .catch((err) => {
        console.error(err);
        setError(true);
      });
  }, [slug]);

  if (error) {
    return (
      <div className="container py-5">
        <h1>Error</h1>
        <p>No se pudo cargar el post.</p>
      </div>
    );
  }

  // Mientras carga el contenido
  if (!attributes) {
    return (
      <div className="container py-5">
        <p>Cargando...</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        {/* Título y descripción para Google */}
        <title>{`${attributes.title} | Dreamsign`}</title>
        <meta name="description" content={attributes.description || 'Artículo del blog Dreamsign'} />
        <link rel="canonical" href={`https://dreamsign.cl/blog/${slug}`} />

        {/* Etiquetas Open Graph para Facebook, LinkedIn, etc. */}
        <meta property="og:type" content="article" />
        <meta property="og:title" content={attributes.title} />
        <meta property="og:description" content={attributes.description || ''} />
        <meta property="og:url" content={`https://dreamsign.cl/blog/${slug}`} />
        <meta property="og:image" content={`https://dreamsign.cl/${attributes.image || 'https://dreamsign.cl/assets/default-og.jpg'}`} />
        <meta property="og:site_name" content="Dreamsign" />

        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={attributes.title} />
        <meta name="twitter:description" content={attributes.description || ''} />
        <meta name="twitter:image" content={`https://dreamsign.cl/${attributes.image || 'https://dreamsign.cl/assets/default-og.jpg'}`} />
        <meta name="twitter:creator" content="@dreamsigncl" />

        {/* Datos estructurados Schema.org */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BlogPosting",
            headline: attributes.title,
            description: attributes.description || '',
            datePublished: attributes.date,
            dateModified: attributes.date,
            author: {
              "@type": "Person",
              name: attributes.author || "Dreamsign"
            },
            publisher: {
              "@type": "Organization",
              name: "Dreamsign",
              logo: {
                "@type": "ImageObject",
                url: "https://dreamsign.cl/assets/logo.png"
              }
            },
            image: attributes.image || "https://dreamsign.cl/assets/default-og.jpg",
            mainEntityOfPage: {
              "@type": "WebPage",
              "@id": `https://dreamsign.cl/blog/${slug}`
            }
          })}
        </script>
      </Helmet>

      <HeaderSinglePage />

      <main role="main" className="blog-post">
        <div className="container">
          <div className="row">
            <div className="col-md-8">
              <div className="header">
                <span className="text-muted">
                  <time dateTime={attributes.date}>{attributes.date}</time> · {attributes.readingTime}
                </span>

                <h1>{attributes.title}</h1>
                
                <div className="author">
                  <div className="image">
                    {attributes.authorImage && (
                      <img
                        src={attributes.authorImage}
                        alt={attributes.author}
                      />
                    )}
                  </div>
                  <div className="content">
                    @{attributes.author}<br/>
                    <small>{attributes.authorRole}</small>
                  </div>
                </div>

                <div className="d-flex justify-content-between">
                  {attributes.categories && (
                    <div className="categories">
                      Categorías: 
                      {attributes.categories.map((cat) => (
                        <span key={cat} className="badge bg-primary ms-1">{cat}</span>
                      ))}
                    </div>
                  )}

                  <ShareBar title={attributes.title} />
                </div>
              </div>

              {attributes.image && (
                <img
                  src={attributes.image}
                  alt={attributes.title}
                  className="img-fluid mb-4"
                />
              )}

              <ReactMarkdown rehypePlugins={[rehypeRaw]}>{body}</ReactMarkdown>
            </div>

            <div className="col-md-4">
              <SidebarRelatedPosts currentSlug={slug} currentCategories={attributes.categories} />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
}