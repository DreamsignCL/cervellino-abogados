function TextAreaField(props){
    return(
        <div className="mb-3">
            <textarea 
                className="form-control" 
                rows={props.rows}
                placeholder={props.placeholder}
                aria-label={props.ariaLabel}
                name={props.name}
                onChange={props.onChange}
                required>
            </textarea>
        </div>
    );
}

export default TextAreaField