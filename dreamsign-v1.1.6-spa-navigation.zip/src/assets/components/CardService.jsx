import { Link } from 'react-router-dom';
import { pushAnalyticsEvent } from '../../utils/analytics';

function CardService(props){
    const handleClick = () => {
        pushAnalyticsEvent('cta_click', {
            cta_name: 'service_card',
            destination: props.serviceLink,
            cta_location: 'services',
            service_name: props.serviceName,
        });
    };
    return(
        <article>
            <Link 
                to={`/${props.serviceLink.replace(/^\//, "")}`} 
                title={`Ir a la página de ${props.serviceName}`} 
                aria-label={`Ir a la página de ${props.serviceName}`}
                onClick={handleClick}>
                <div className="card card-service">
                    <div className={'icon ' + props.serviceBgColor } >
                        { props.serviceIcon }
                        <span className="sr-only">{props.serviceName} - Icono</span>
                    </div>
                    <div className="card-body">
                        <h3 className="card-title">{ props.serviceName }</h3>
                        <p className="card-text">{ props.serviceContent }</p>
                        <div className="btn btn-primary rounded-pill">Ver más</div>
                    </div>
                </div>
            </Link>
        </article>
    );
}

export default CardService