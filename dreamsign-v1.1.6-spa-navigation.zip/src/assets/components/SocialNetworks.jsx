import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInstagram, faFacebook, faWhatsapp, faLinkedin, faXTwitter } from '@fortawesome/free-brands-svg-icons';
import { faMobileScreenButton } from '@fortawesome/free-solid-svg-icons';
import { pushAnalyticsEvent } from '../../utils/analytics';

function SocialNetworks() {
    const socialNetworkList = [
        {
            id: 1,
            name: 'Instagram',
            title: 'Visita nuestra página en Instagram',
            icon: <FontAwesomeIcon icon={faInstagram} aria-hidden="true" />,
            link: 'https://www.instagram.com/dreamsigncl/'
        },
        {
            id: 2,
            name: 'Facebook',
            title: 'Visita nuestra página en Facebook',
            icon: <FontAwesomeIcon icon={faFacebook} aria-hidden="true" />,
            link: 'https://www.facebook.com/DreamsignCL'
        },
        {
            id: 3,
            name: 'Linkedin',
            title: 'Visita nuestra página en Linkedin',
            icon: <FontAwesomeIcon icon={faLinkedin} aria-hidden="true" />,
            link: 'https://www.linkedin.com/company/dreamsigncl/'
        },
        {
            id: 4,
            name: 'X',
            title: 'Visita nuestra página en X',
            icon: <FontAwesomeIcon icon={faXTwitter} aria-hidden="true" />,
            link: 'https://x.com/DreamsignCL'
        },
        {
            id: 5,
            name: 'WhatsApp',
            title: 'Escríbenos a nuestro WhatsApp',
            icon: <FontAwesomeIcon icon={faWhatsapp} aria-hidden="true" />,
            link: 'https://wa.me/+56937351500'
        },
        {
            id: 6,
            name: 'Teléfono',
            title: 'Llámanos por Teléfono',
            icon: <FontAwesomeIcon icon={faMobileScreenButton} aria-hidden="true" />,
            link: 'tel:+56937351500'
        },
    ];

    const socialNetworkItems = socialNetworkList.map(socialNetworkItem => 
        <li key={socialNetworkItem.id}>
            <a 
                href={socialNetworkItem.link}
                title={socialNetworkItem.title}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={socialNetworkItem.title}
                onClick={() => {
                    if (socialNetworkItem.name === 'WhatsApp') {
                        pushAnalyticsEvent('whatsapp_click', {
                            click_location: 'contact',
                            destination_type: 'direct_message',
                        });
                    } else if (socialNetworkItem.name === 'Teléfono') {
                        pushAnalyticsEvent('phone_click', {
                            click_location: 'contact',
                        });
                    }
                }}>
                {socialNetworkItem.icon}
            </a>
        </li>
    );

    return (
        <nav className="rrss-footer" aria-label="Enlaces a nuestras redes sociales">
            <ul>
                {socialNetworkItems}
            </ul>
        </nav>
    );
}

export default SocialNetworks;
