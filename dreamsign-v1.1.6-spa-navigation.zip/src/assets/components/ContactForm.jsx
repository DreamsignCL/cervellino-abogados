import React, { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPaperPlane } from "@fortawesome/free-solid-svg-icons";
import ReCAPTCHA from 'react-google-recaptcha';
import { trackContactEvent } from '../../utils/analytics';

const RECAPTCHA_SITE_KEY = "6LfRQi8rAAAAAFtDYIvLok343q5Kk76KhfGt6oU5"; // <-- Reemplaza esto con tu Site Key de Google

function ContactForm() {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();
  const [mensaje, setMensaje] = useState("");
  const [clase, setClase] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [captchaToken, setCaptchaToken] = useState(null);
  const formStarted = useRef(false);

  const registrarInicioFormulario = () => {
    if (formStarted.current) return;

    formStarted.current = true;
    trackContactEvent("contact_form_start");
  };

  const enviar = async (data) => {
    if (!captchaToken) {
      trackContactEvent("contact_form_error", { error_type: "captcha_missing" });
      setMensaje("Por favor completa el CAPTCHA");
      setClase("alert-danger");
      return;
    }

    setEnviando(true);

    // Incluimos el token de reCAPTCHA en los datos
    const datosConCaptcha = {
      ...data,
      "g-recaptcha-response": captchaToken,
    };

    try {
      const response = await fetch("https://dreamsign.cl/send_email.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(datosConCaptcha).toString(), // 👈 Usamos datosConCaptcha aquí
      });

      const result = await response.json();
      if (result.status === "success") {
        trackContactEvent("contact_form_submit");
        setMensaje("Correo enviado exitosamente");
        setClase("alert-success");
        reset(); // Limpia los campos del formulario
        setCaptchaToken(null); // Reinicia el captcha
      } else {
        trackContactEvent("contact_form_error", { error_type: "server_rejected" });
        setMensaje(`Error: ${result.message}`);
        setClase("alert-danger");
      }
    } catch (error) {
      console.error("Error enviando formulario de contacto:", error);
      trackContactEvent("contact_form_error", { error_type: "network_error" });
      setMensaje("No pudimos enviar tu mensaje. Por favor inténtalo nuevamente o contáctanos por WhatsApp.");
      setClase("alert-danger");
    } finally {
      setEnviando(false);
    }
  };

  return (
    <>
      {mensaje && (
        <div className={`alert ${clase}`} role="status" aria-live="polite">
          {mensaje}
        </div>
      )}
      <form onSubmit={handleSubmit(enviar)} onFocusCapture={registrarInicioFormulario} role="form">
        <div className="mb-3">
          <label htmlFor="Nombre" className="form-label">Nombre</label>
          <input
            type="text"
            className={`form-control rounded-pill ${errors.Nombre ? 'is-invalid' : ''}`}
            id="Nombre"
            placeholder="Nombre"
            aria-invalid={errors.Nombre ? 'true' : 'false'}
            aria-describedby="nombreError"
            {...register("Nombre", {
              required: "Debes ingresar un nombre",
              minLength: { value: 2, message: "No debes usar menos de 2 caracteres" },
              maxLength: { value: 50, message: "No debes usar más de 50 caracteres" },
            })}
          />
          {errors.Nombre && <span id="nombreError" className="error-message" role="alert">{errors.Nombre.message}</span>}
        </div>

        <div className="mb-3">
          <label htmlFor="Email" className="form-label">Email</label>
          <input
            type="email"
            className={`form-control rounded-pill ${errors.Email ? 'is-invalid' : ''}`}
            id="Email"
            placeholder="Email"
            aria-invalid={errors.Email ? 'true' : 'false'}
            aria-describedby="emailError"
            {...register("Email", {
              required: "Debes ingresar un email",
              minLength: { value: 2, message: "No debes usar menos de 2 caracteres" },
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                message: "Debes usar una dirección de correo válida",
              },
            })}
          />
          {errors.Email && <span id="emailError" className="error-message" role="alert">{errors.Email.message}</span>}
        </div>

        <div className="mb-3">
          <label htmlFor="Asunto" className="form-label">Asunto</label>
          <input
            type="text"
            className={`form-control rounded-pill ${errors.Asunto ? 'is-invalid' : ''}`}
            id="Asunto"
            placeholder="Asunto"
            aria-invalid={errors.Asunto ? 'true' : 'false'}
            aria-describedby="asuntoError"
            {...register("Asunto", {
              required: "Debes ingresar un asunto",
              minLength: { value: 2, message: "No debes usar menos de 2 caracteres" },
              maxLength: { value: 50, message: "No debes usar más de 50 caracteres" },
            })}
          />
          {errors.Asunto && <span id="asuntoError" className="error-message" role="alert">{errors.Asunto.message}</span>}
        </div>

        <div className="mb-3">
          <label htmlFor="Comentario" className="form-label">Comentario</label>
          <textarea
            className={`form-control ${errors.Comentario ? 'is-invalid' : ''}`}
            id="Comentario"
            rows="4"
            placeholder="Comentario"
            aria-invalid={errors.Comentario ? 'true' : 'false'}
            aria-describedby="comentarioError"
            {...register("Comentario", {
              required: "Debes ingresar un comentario",
              minLength: { value: 2, message: "No debes usar menos de 2 caracteres" },
              maxLength: { value: 500, message: "No debes usar más de 500 caracteres" },
            })}
          />
          {errors.Comentario && <span id="comentarioError" className="error-message" role="alert">{errors.Comentario.message}</span>}
        </div>

        {/* CAPTCHA */}
        <div className="mb-3">
          <ReCAPTCHA
            sitekey={RECAPTCHA_SITE_KEY}
            onChange={(token) => setCaptchaToken(token)}
            onExpired={() => setCaptchaToken(null)}
          />
        </div>

        <div className="d-flex justify-content-end">
          <button
            className="btn btn-primary rounded-pill"
            type="submit"
            aria-label="Enviar email"
            disabled={enviando}
          >
            {enviando ? "Enviando..." : "Enviar"}{" "}
            <FontAwesomeIcon icon={faPaperPlane} aria-hidden="true" />
          </button>
        </div>
      </form>
    </>
  );
}

export default ContactForm;
