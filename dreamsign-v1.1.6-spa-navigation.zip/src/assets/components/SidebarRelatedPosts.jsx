import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function SidebarRelatedPosts({ currentSlug, currentCategories = [] }) {
  const [relatedPosts, setRelatedPosts] = useState([]);

  useEffect(() => {
    fetch('/blog/index.json')
      .then((res) => res.json())
      .then((posts) => {
        const filtered = posts
          .filter((post) => {
            // Excluir el post actual
            if (post.slug === currentSlug) return false;

            // Debe tener al menos una categoría en común
            const hasCommonCategory = post.categories?.some(cat =>
              currentCategories.includes(cat)
            );

            return post.published && hasCommonCategory;
          })
          .sort((a, b) => new Date(b.date) - new Date(a.date))
          .slice(0, 3); // Limita a 3 relacionados

        setRelatedPosts(filtered);
      })
      .catch((err) => {
        console.error('Error cargando posts relacionados:', err);
      });
  }, [currentSlug, currentCategories]);

  if (relatedPosts.length === 0) return null;

  return (
    <div className="related-posts mb-5">
      <h5 className="mb-3">También te puede interesar</h5>
      <ul className="list-unstyled">
        {relatedPosts.map((post) => (
          <li key={post.slug} className="mb-3">
            <Link to={`/blog/${post.slug}`} className="text-decoration-none">
              <div className="d-flex align-items-start">
                <img
                  src={post.image || '/blog/assets/default.jpg'}
                  alt={post.title}
                  width="60"
                  height="60"
                  className="me-3 rounded"
                  style={{ objectFit: 'cover' }}
                />
                <div>
                  <h6 className="mb-1">{post.title}</h6>
                  <small className="text-muted">{post.date}</small>
                </div>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}