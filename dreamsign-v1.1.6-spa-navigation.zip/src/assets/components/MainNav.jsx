import React, { useState, useEffect, useRef } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faTimes } from '@fortawesome/free-solid-svg-icons';
import { Link, useLocation, useNavigate } from 'react-router-dom';

function MainNav(){
    const [isActive, setIsActive] = useState(false);
    const menuRef = useRef(null);
    const location = useLocation();
    const navigate = useNavigate();

    const toggleNav = () => {
        setIsActive(!isActive);
    };

    const handleInternalNavigation = () => {
        setIsActive(false);
    };

    const handleHomeSectionNavigation = (sectionId, event) => {
        event.preventDefault();
        setIsActive(false);
        navigate(`/#${sectionId}`);
    };

    useEffect(() => {
        if (isActive && menuRef.current) {
            menuRef.current.querySelector("a")?.focus();
        }
    }, [isActive]);

    useEffect(() => {
        if (!location.hash) return;

        const sectionId = decodeURIComponent(location.hash.slice(1));
        const scrollToSection = () => {
            document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth" });
        };

        requestAnimationFrame(scrollToSection);
    }, [location.pathname, location.hash]);

    return(
        <div ref={menuRef}>
            <button 
                className="trigger-menu d-md-none" 
                onClick={toggleNav}
                type="button" 
                aria-label="Abrir menú">
                <FontAwesomeIcon icon={faBars} aria-hidden="true" size="2x" />
            </button>

            <nav className="main-menu-desktop d-none d-md-block" aria-label="Navegación principal">
                <ul>
                    <li>
                        <Link to="/" title="Volver al inicio" onClick={handleInternalNavigation}>Inicio</Link>
                    </li>
                    <li>
                        <Link to="/#services" title="Ver nuestros servicios" onClick={(event) => handleHomeSectionNavigation("services", event)}>Servicios</Link>
                    </li>
                    <li>
                        <Link to="/#about_us" title="Conoce sobre nosotros" onClick={(event) => handleHomeSectionNavigation("about_us", event)}>Nosotros</Link>
                    </li>
                    <li>
                        <Link to="/#clients" title="Descubre nuestros clientes" onClick={(event) => handleHomeSectionNavigation("clients", event)}>Clientes</Link>
                    </li>
                    <li>
                        <Link to="/blog" title="Revisa nuestro Blog" onClick={handleInternalNavigation}>Blog</Link>
                    </li>
                    <li>
                        <a href="#contact" title="Contáctanos para mayor información">Contacto</a>
                    </li>
                </ul>
            </nav>

            <div 
                id="menu_mobile" 
                className="main-menu-mobile"
                tabIndex="-1" 
                aria-labelledby="menuMobileLabel" 
                aria-hidden={!isActive}
                style={{ display: isActive ? "block" : "none" }}>

                <div className="menu-content">
                    <div className="d-flex justify-content-between">
                        <h4 id="menuMobileLabel" className="text-primary">Conoce nuestras secciones</h4>
                        <button 
                            className="close-menu" 
                            onClick={toggleNav}
                            type="button" 
                            aria-label="Cerrar menú">
                            <FontAwesomeIcon icon={faTimes} aria-hidden="true" size="2x" />
                        </button>
                    </div>
                    
                    <nav aria-label="Navegación principal">
                        <ul>
                            <li>
                                <Link to="/" title="Volver al inicio" onClick={handleInternalNavigation}>Inicio</Link>
                            </li>
                            <li>
                                <Link to="/design" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Diseño corporativo</Link>
                            </li>
                            <li>
                                <Link to="/web-development" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Desarrollo web</Link>
                            </li>
                            <li>
                                <Link to="/hosting" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Hosting</Link>
                            </li>
                            <li>
                                <Link to="/seo-marketing" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>SEO / SEM</Link>
                            </li>
                            <li>
                                <Link to="/user-experience" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Diseño UX</Link>
                            </li>
                            <li>
                                <Link to="/quality-assurance" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Quality Assurance</Link>
                            </li>
                            <li>
                                <Link to="/accessibility" title="Conoce nuestro servicio" onClick={handleInternalNavigation}>Accesibilidad</Link>
                            </li>
                            <li>
                                <Link to="/blog" title="Revisa nuestro Blog" onClick={handleInternalNavigation}>Blog</Link>
                            </li>
                            <li>
                                <a href="#contact" title="Contáctanos para mayor información">Contacto</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    );
}

export default MainNav