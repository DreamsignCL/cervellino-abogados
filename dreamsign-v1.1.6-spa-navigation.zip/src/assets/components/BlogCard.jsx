import { Link } from 'react-router-dom';
import { pushAnalyticsEvent } from '../../utils/analytics';

export default function BlogCard({ post }) {
    const handleClick = () => {
        pushAnalyticsEvent('cta_click', {
            cta_name: 'blog_post',
            destination: `/blog/${post.slug}`,
            cta_location: 'blog_card',
            content_type: 'blog',
            content_slug: post.slug,
        });
    };

    return (
        <Link className="blog-card" to={`/blog/${post.slug}`} onClick={handleClick}>
            <div className="image">
                <img src={post.image || '/blog/assets/default.jpg'} alt={post.title} />
            </div>
            <span className="text-muted">
                {post.date} · {post.readingTime}
            </span>
            <h3>{post.title}</h3>
            <p className="text-muted">{post.description}</p>
        </Link>
    );
}
