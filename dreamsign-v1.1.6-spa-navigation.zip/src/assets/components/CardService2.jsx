function CardService2(props){
    return(
        <div className="card card-service">
            <div className="image-content">
                <img className="card-img-top" src={ props.serviceImage } alt="" />
            </div>
            <div className="card-body">
                <h3 className="card-title">{ props.serviceName }</h3>
                <p className="card-text">{ props.serviceContent }</p>
            </div>
        </div>
    );
}

export default CardService2