const ANALYTICS_ENABLED = typeof window !== 'undefined';

function getDataLayer() {
  if (!ANALYTICS_ENABLED) return null;

  window.dataLayer = window.dataLayer || [];
  return window.dataLayer;
}

export function pushAnalyticsEvent(event, parameters = {}) {
  const dataLayer = getDataLayer();
  if (!dataLayer || !event) return;

  dataLayer.push({
    event,
    ...parameters,
  });
}

export function trackPageView({ path, title } = {}) {
  const pagePath = (path || window.location.pathname).split('?')[0] || '/';
  const pageTitle = title || document.title;

  pushAnalyticsEvent('page_view', {
    // page_path es deliberadamente solo pathname: no incluye query params.
    page_path: pagePath,
    page_location: window.location.href,
    ...(pageTitle ? { page_title: pageTitle } : {}),
  });
}

export function trackCtaClick({ ctaName, destination, location } = {}) {
  pushAnalyticsEvent('cta_click', {
    cta_name: ctaName,
    destination,
    cta_location: location,
  });
}

export function trackContactEvent(event, parameters = {}) {
  pushAnalyticsEvent(event, {
    form_name: 'contact',
    ...parameters,
  });
}
