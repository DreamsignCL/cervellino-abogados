import logo from './assets/img/logo-dreamsign.svg';
import MainNav from './assets/components/MainNav'
import { Link } from 'react-router-dom';

function Header(){
    return(
        <header className="header-single-page">
            <div className="container">
                <div className="d-flex justify-content-between align-items-center">
                    <Link to="/" aria-label="Ir a la página de inicio">
                        <img src={logo} alt="Logotipo de Dreamsign"></img>
                    </Link>

                    <MainNav />
                </div>
            </div>
        </header>
    );
}

export default Header