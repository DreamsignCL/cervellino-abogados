// generateIndex.js
const fs = require('fs');
const path = require('path');
const fm = require('front-matter');

const blogDir = path.join(__dirname, 'public', 'blog');
const outputPath = path.join(blogDir, 'index.json');

// Ignorar carpetas como "assets" o cualquier subcarpeta
const files = fs.readdirSync(blogDir).filter(
  file => file.endsWith('.md') && fs.statSync(path.join(blogDir, file)).isFile()
);

const posts = files.map(filename => {
  const slug = filename.replace('.md', '');
  const filePath = path.join(blogDir, filename);
  const content = fs.readFileSync(filePath, 'utf-8');
  const { attributes } = fm(content);

  return {
    slug,
    ...attributes
  };
});

posts.sort((a, b) => new Date(b.date) - new Date(a.date));

fs.writeFileSync(outputPath, JSON.stringify(posts, null, 2));
console.log(`✅ index.json generado con ${posts.length} posts en /public/blog`);
