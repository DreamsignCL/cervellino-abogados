const fs = require('fs');
const path = require('path');

const SITE_URL = 'https://dreamsign.cl';

const staticUrls = [
  '/',
  '/design',
  '/web-development',
  '/hosting',
  '/seo-marketing',
  '/user-experience',
  '/quality-assurance',
  '/accessibility',
  '/marketing',
  '/webinars',
  '/dsrest',
  '/blog'
];

const staticEntries = staticUrls.map(url => `
  <url>
    <loc>${SITE_URL}${url}</loc>
    <lastmod>${new Date().toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
`);

const blogIndexPath = path.join(__dirname, 'public', 'blog', 'index.json');
let blogEntries = [];

try {
  const blogData = JSON.parse(fs.readFileSync(blogIndexPath, 'utf8'));

  blogEntries = blogData
    .filter(post => post.published)
    .map(post => `
  <url>
    <loc>${SITE_URL}/blog/${post.slug}</loc>
    <lastmod>${new Date(post.date).toISOString()}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  `);
} catch (error) {
  console.error('Error leyendo index.json:', error);
}

const sitemapContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
    http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
${staticEntries.join('\n')}
${blogEntries.join('\n')}
</urlset>`;

fs.writeFileSync(path.join(__dirname, 'public', 'sitemap.xml'), sitemapContent);
console.log('✅ Sitemap actualizado con entradas del blog.');
